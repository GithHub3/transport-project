SET NAMES utf8mb4; SET time_zone = '+00:00';

CREATE TABLE coins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL,
    name VARCHAR(100) UNIQUE NOT NULL,
    icon VARCHAR(10) ,
    is_main tinyint(1) NOT NULL DEFAULT 0,
    sts ENUM('ok','sale','buy','stop') NOT NULL DEFAULT 'ok'
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE countrys (
    id INT PRIMARY KEY,
    name_ar VARCHAR(400), 
    name_en VARCHAR(400), 
    code VARCHAR(50),
    note TEXT
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE states (
    id INT AUTO_INCREMENT PRIMARY KEY,
    country_id INT ,
    name_ar VARCHAR(400), 
    name_en VARCHAR(400), 
    code VARCHAR(50),
    note TEXT,
    FOREIGN KEY (country_id) REFERENCES countrys(id) ON DELETE SET NULL

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE prices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    from_country_id INT,
    to_country_id INT ,
    coin_id INT,
    min_price_m3 DECIMAL(10,2) NOT NULL ,
    max_price_m3 DECIMAL(10,2) NOT NULL ,

    min_price_kg DECIMAL(10,2) NOT NULL ,
    max_price_kg DECIMAL(10,2) NOT NULL ,
    FOREIGN KEY (from_country_id) REFERENCES countrys(id) ON DELETE SET NULL,
    FOREIGN KEY (to_country_id) REFERENCES countrys(id) ON DELETE SET NULL,
    FOREIGN KEY (coin_id) REFERENCES coins(id) ON DELETE SET NULL
  

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE shipments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    from_state_id INT,
    to_state_id INT ,
    go_date DATE DEFAULT NULL,
    arrive_date DATE DEFAULT NULL,
    sts ENUM('stop','full','close','move' , 'arrive') NOT NULL DEFAULT 'stop',
    FOREIGN KEY (from_state_id) REFERENCES states(id) ON DELETE SET NULL,
    FOREIGN KEY (to_state_id) REFERENCES states(id) ON DELETE SET NULL



)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE ship_follows (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ship_id INT NOT NULL,
    user_id INT ,
    follow VARCHAR(500)NOT NULL,
    dt DATETIME DEFAULT CURRENT_TIMESTAMP,
    note TEXT,
    FOREIGN KEY (ship_id) REFERENCES shipments(id) ON DELETE CASCADE



)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE containers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ship_id INT,
    num VARCHAR(400) NOT NULL,
    size ENUM('20ft','40ft','40ft_HC'),
    sts ENUM('loading','full','close') NOT NULL DEFAULT 'loading',
    note TEXT,
    FOREIGN KEY (ship_id) REFERENCES shipments(id) ON DELETE SET NULL


)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE cstms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    state_id INT ,
    name_ar VARCHAR(400), 
    name_en VARCHAR(400), 
    email VARCHAR(100),
    phone1 VARCHAR(100),
    phone2 VARCHAR(100),
    address VARCHAR(500),
    location VARCHAR(500),
    FOREIGN KEY (state_id) REFERENCES states(id) ON DELETE SET NULL
     

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE cstm_inv (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ship_id INT,
    cstm_id_send INT,
    cstm_id_receive INT,
    state_id_from INT,
    state_id_to INT,
    user_id INT ,
    coin_id INT,
    inv_num VARCHAR(400), 
    dt DATETIME DEFAULT CURRENT_TIMESTAMP,
    amount DECIMAL(10,2) NOT NULL,
    paid DECIMAL(10,2) NOT NULL,
    note TEXT DEFAULT NULL ,
    FOREIGN KEY (ship_id) REFERENCES shipments(id) ON DELETE SET NULL,
    FOREIGN KEY (cstm_id_send) REFERENCES cstms(id) ON DELETE SET NULL,
    FOREIGN KEY (cstm_id_receive) REFERENCES cstms(id) ON DELETE SET NULL,
    FOREIGN KEY (state_id_from) REFERENCES states(id) ON DELETE SET NULL,
    FOREIGN KEY (state_id_to) REFERENCES states(id) ON DELETE SET NULL,
    FOREIGN KEY (coin_id) REFERENCES coins(id) ON DELETE SET NULL
  

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



CREATE TABLE cstm_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cstm_inv_id INT,
    coin_id INT,
    name_ar VARCHAR(400), 
    name_en VARCHAR(400), 
    dt DATETIME DEFAULT CURRENT_TIMESTAMP,
    amount DECIMAL(10,2) NOT NULL,
    paid DECIMAL(10,2) NOT NULL,
    note TEXT DEFAULT NULL ,  
    FOREIGN KEY (cstm_inv_id) REFERENCES cstm_inv(id) ON DELETE CASCADE,
    FOREIGN KEY (coin_id) REFERENCES coins(id) ON DELETE SET NULL

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



CREATE TABLE item_classes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT,
    name_ar VARCHAR(400), 
    name_en VARCHAR(400), 
    unit ENUM('m3','kg') NOT NULL DEFAULT 'm3',
    note TEXT DEFAULT NULL,
    FOREIGN KEY (item_id) REFERENCES cstm_items(id) ON DELETE CASCADE


)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE class_parts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    class_id INT,
    qty INT NOT NULL DEFAULT 1,
    height DECIMAL(10,2) ,
    length DECIMAL(10,2) ,
    width DECIMAL(10,2) ,
    kg DECIMAL(10,2) ,
    note TEXT DEFAULT NULL ,
    FOREIGN KEY (class_id) REFERENCES item_classes(id) ON DELETE CASCADE

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE pkgs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cstm_inv_id INT,
    qty INT NOT NULL DEFAULT 1,
    height DECIMAL(10,2) ,
    length DECIMAL(10,2) ,
    width DECIMAL(10,2) ,
    kg DECIMAL(10,2) ,
    note TEXT DEFAULT NULL,    
    FOREIGN KEY (cstm_inv_id) REFERENCES cstm_inv(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;






-- coin_chng
CREATE TABLE coin_chng (
    id INT AUTO_INCREMENT PRIMARY KEY,
    from_coin_id INT NOT NULL,
    to_coin_id INT NOT NULL,
    price DECIMAL(10,2) NOT NULL, 
    dt_start DATETIME DEFAULT CURRENT_TIMESTAMP,
    dt_end DATETIME DEFAULT NULL,

    is_active tinyint(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (from_coin_id) REFERENCES coins(id) ON DELETE CASCADE,
    FOREIGN KEY (to_coin_id) REFERENCES coins(id) ON DELETE CASCADE


)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


