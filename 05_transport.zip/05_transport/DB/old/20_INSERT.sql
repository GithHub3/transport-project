INSERT INTO states (name_ar, name_en, code) VALUES
('ألاباما', 'Alabama', 'AL'),
('ألاسكا', 'Alaska', 'AK'),
('أريزونا', 'Arizona', 'AZ'),
('أركنساس', 'Arkansas', 'AR'),
('كاليفورنيا', 'California', 'CA'),
('كولورادو', 'Colorado', 'CO'),
('كونيتيكت', 'Connecticut', 'CT'),
('ديلاوير', 'Delaware', 'DE'),
('فلوريدا', 'Florida', 'FL'),
('جورجيا', 'Georgia', 'GA'),
('هاواي', 'Hawaii', 'HI'),
('أيداهو', 'Idaho', 'ID'),
('إلينوي', 'Illinois', 'IL'),
('إنديانا', 'Indiana', 'IN'),
('آيوا', 'Iowa', 'IA'),
('كانساس', 'Kansas', 'KS'),
('كنتاكي', 'Kentucky', 'KY'),
('لويزيانا', 'Louisiana', 'LA'),
('مين', 'Maine', 'ME'),
('ميريلاند', 'Maryland', 'MD'),
('ماساتشوستس', 'Massachusetts', 'MA'),
('ميشيغان', 'Michigan', 'MI'),
('مينيسوتا', 'Minnesota', 'MN'),
('مسيسيبي', 'Mississippi', 'MS'),
('ميزوري', 'Missouri', 'MO'),
('مونتانا', 'Montana', 'MT'),
('نبراسكا', 'Nebraska', 'NE'),
('نيفادا', 'Nevada', 'NV'),
('نيوهامبشير', 'New Hampshire', 'NH'),
('نيو جيرسي', 'New Jersey', 'NJ'),
('نيو مكسيكو', 'New Mexico', 'NM'),
('نيويورك', 'New York', 'NY'),
('كارولاينا الشمالية', 'North Carolina', 'NC'),
('داكوتا الشمالية', 'North Dakota', 'ND'),
('أوهايو', 'Ohio', 'OH'),
('أوكلاهوما', 'Oklahoma', 'OK'),
('أوريغون', 'Oregon', 'OR'),
('بنسيلفانيا', 'Pennsylvania', 'PA'),
('رود آيلاند', 'Rhode Island', 'RI'),
('كارولاينا الجنوبية', 'South Carolina', 'SC'),
('داكوتا الجنوبية', 'South Dakota', 'SD'),
('تينيسي', 'Tennessee', 'TN'),
('تكساس', 'Texas', 'TX'),
('يوتا', 'Utah', 'UT'),
('فيرمونت', 'Vermont', 'VT'),
('فرجينيا', 'Virginia', 'VA'),
('واشنطن', 'Washington', 'WA'),
('فرجينيا الغربية', 'West Virginia', 'WV'),
('ويسكونسن', 'Wisconsin', 'WI'),
('وايومنغ', 'Wyoming', 'WY');






INSERT INTO states (name_ar, name_en, code) VALUES
('واشنطن العاصمة', 'District of Columbia', 'DC'),
('بورتوريكو', 'Puerto Rico', 'PR'),
('غوام', 'Guam', 'GU'),
('ساموا الأمريكية', 'American Samoa', 'AS'),
('جزر ماريانا الشمالية', 'Northern Mariana Islands', 'MP'),
('جزر العذراء الأمريكية', 'U.S. Virgin Islands', 'VI');







INSERT INTO governorates (name_ar, name_en, code) VALUES
('أبين', 'Abyan', 'AB'),
('عدن', 'Aden', 'AD'),
('الضالع', 'Ad Dali''', 'DA'),
('البيضاء', 'Al Bayda''', 'BA'),
('الحديدة', 'Al Hudaydah', 'HU'),
('الجوف', 'Al Jawf', 'JA'),
('المهرة', 'Al Mahrah', 'MR'),
('المحويت', 'Al Mahwit', 'MW'),
('أرخبيل سقطرى', 'Socotra', 'SU'),
('عمران', 'Amran', 'AM'),
('ذمار', 'Dhamar', 'DH'),
('حضرموت', 'Hadramawt', 'HD'),
('حجة', 'Hajjah', 'HJ'),
('إب', 'Ibb', 'IB'),
('لحج', 'Lahij', 'LA'),
('مأرب', 'Ma''rib', 'MA'),
('ريمة', 'Raymah', 'RA'),
('صعدة', 'Sa''dah', 'SD'),
('صنعاء', 'Sana''a', 'SN'),
('شبوة', 'Shabwah', 'SH'),
('تعز', 'Ta''izz', 'TA'),
('أمانة العاصمة', 'Amanat Al Asimah', 'SA'),
('اليمن', 'Yemen', 'YE');   




