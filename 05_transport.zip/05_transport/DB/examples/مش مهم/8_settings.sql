



-- جدول المعلومات الاساسية

CREATE TABLE IF NOT EXISTS main_data (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  company_name        VARCHAR(500) NOT NULL,
location_url VARCHAR(2000)  NULL,
location_disc VARCHAR(2000) NULL,
web_url VARCHAR(2000) NULL,
web_barcode VARCHAR(2000) NULL,


email VARCHAR(500) NULL,
main_logo TEXT NULL,
normal_logo TEXT NULL,
inv_logo TEXT NULL,
motto TEXT NULL,
note VARCHAR(10000) NULL,
company_type VARCHAR(500) NULL,

  is_active    TINYINT(1) NOT NULL DEFAULT 1,
  cr_by    INT NULL,
  upd_by    INT NULL,
  cr_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  upd_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS main_setting (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sale_pdt_by ENUM('end_dt','one_price'),
  sale_pdt_sort ENUM('ASC','DESC'),

  dflt_pay_salary ENUM('day','week','month') DEFAULT 'month',
  dflt_pay_first_salary ENUM('now','next','none') DEFAULT 'none',
  dflt_date_pay_salary ENUM('selected_day','last_pay_date','first_pay_date','none') DEFAULT 'none',
  dflt_day_pay_salary VARCHAR(2) DEFAULT '01',

  finger_system ENUM('yes','no') DEFAULT 'no'

 
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

