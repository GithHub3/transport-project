









    -- dsct DECIMAL(10,2) DEFAULT 0,
    -- end_amnt DECIMAL(10,2) DEFAULT 0,
 











-- sales
CREATE TABLE sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    inv_num VARCHAR(100) DEFAULT NULL,
    buyer_id INT NOT NULL,
    coin_id INT NOT NULL,
    dt DATETIME DEFAULT CURRENT_TIMESTAMP,
    amount DECIMAL(10,2) NOT NULL,
    paid DECIMAL(10,2) NOT NULL,
    note TEXT DEFAULT NULL,

    sts ENUM('ok','del','wait','agree','no','draft','procssing','sent') NOT NULL DEFAULT 'ok',

    check_dt DATETIME DEFAULT NULL,
    check_seller_id INT NULL,
    check_note TEXT DEFAULT NULL
   


)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Invoice Items
CREATE TABLE sale_itms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sal_id INT NOT NULL,
    pdt_id INT NOT NULL,
    coin_id INT NOT NULL,
    qty INT NOT NULL,
    one_price DECIMAL(10,2) NOT NULL

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE sale_rtr (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sale_id INT NOT NULL,                  

    coin_id INT NOT NULL,                  -- الفاتورة الأصلية
    dt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    amount DECIMAL(10,2) NOT NULL,          
-- المبلغ المرجع

    note TEXT DEFAULT NULL,

    sts ENUM('ok','del','wait','agree','no','draft','procssing','sent') NOT NULL DEFAULT 'ok',

    check_dt DATETIME DEFAULT NULL,
    check_note TEXT DEFAULT NULL
   


) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE sale_rtr_itms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sal_rtr_id INT NOT NULL,
    coin_id INT NOT NULL, 
    sale_itms_id INT NOT NULL,           
    qty INT NOT NULL

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


----------------------------------------
----------------------------------------
----------------------------------------
