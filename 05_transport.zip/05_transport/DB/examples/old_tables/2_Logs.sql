
-- سندات الدفع او الاستلام
CREATE TABLE logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_type VARCHAR(200) NOT NULL, -- table name ex : 'emps','cstm','supp',...
    table_id INT ,
    user_type ENUM('emp','cstm') NOT NULL,
    user_id INT ,
    dt DATETIME DEFAULT CURRENT_TIMESTAMP,
    note TEXT DEFAULT NULL,
    log_type ENUM('edit','add','del') NOT NULL,


)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
  



--
-- بنية الجدول `funds`
--

