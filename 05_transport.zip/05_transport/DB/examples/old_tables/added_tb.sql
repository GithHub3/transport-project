


CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pdt_id INT NOT NULL,
    cstm_id INT NULL,      
    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT NULL,                   
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (pdt_id) REFERENCES pdts(id) ON DELETE CASCADE,
    FOREIGN KEY (cstm_id) REFERENCES cstms(id) ON DELETE SET NULL 
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



ALTER TABLE `images_and_files` 
ADD `col_id` INT NOT NULL 
AFTER `table_name`;




ALTER TABLE `cstms` 
ADD `coin_id` INT NOT NULL 
AFTER `id`;