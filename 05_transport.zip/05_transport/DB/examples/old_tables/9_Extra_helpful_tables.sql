-- جدول التخطي او التجاهل يعني اذا في فاتورة لم يدفع مبلغها كاملا ولا نريد ان تؤثر علئ الحسابات نحطها هنا
CREATE TABLE skips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(200) NOT NULL, -- table name ex : 'emps','cstm','supp',...
    col_id INT NOT NULL,
    user_id INT ,
    skip_type ENUM('all','only_error')
    dt DATETIME DEFAULT CURRENT_TIMESTAMP,
    why TEXT DEFAULT NULL,
    note TEXT DEFAULT NULL

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
  
CREATE TABLE phone_numbers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(200) NOT NULL, -- table name ex : 'emps','cstm','supp',...
    col_id INT NOT NULL,
    phone VARCHAR(100) NOT NULL,
    phone_type ENUM('static','mobile') NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

  
CREATE TABLE images_and_files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(200) NOT NULL, -- table name ex : 'emps','cstm','supp',...
    col_id INT NOT NULL,
    descrip TEXT ;
    file_name TEXT NOT NULL, 
    file_extension VARCHAR(200) NOT NULL, 
    is_active TINYINT(1) NOT NULL DEFAULT 1

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
  
