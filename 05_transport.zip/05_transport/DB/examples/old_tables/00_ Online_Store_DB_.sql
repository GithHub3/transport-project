

SET NAMES utf8mb4; SET time_zone = '+03:00';


CREATE TABLE states (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(500) NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE citys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    state_id INT ,
    name VARCHAR(500) NOT NULL,
    FOREIGN KEY (state_id) REFERENCES states(id) ON DELETE CASCADE 

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE IF NOT EXISTS users (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    fullname        VARCHAR(100) NOT NULL,
    username        VARCHAR(100) NOT NULL UNIQUE,
    pass         VARCHAR(255) NOT NULL,
    phone        VARCHAR(100) ,
    email        VARCHAR(100) ,
    user_type ENUM('admin','finance','prodect_manager','support') NOT NULL,

    sts ENUM('ok','stop','delete') NOT NULL DEFAULT 'ok'

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;




CREATE TABLE IF NOT EXISTS cstms (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    fullname        VARCHAR(100) NOT NULL,
    username        VARCHAR(100) NOT NULL UNIQUE,
    pass         VARCHAR(255) NOT NULL,
    phone        VARCHAR(100) ,
    email        VARCHAR(100) ,
    city_id INT ,
    location_url TEXT ,
    user_type ENUM('seller','buyer') NOT NULL DEFAULT 'buyer',
    check_code VARCHAR(100) ,
    sts ENUM('ok','stop','delete','on_check') NOT NULL ,
    FOREIGN KEY (city_id) REFERENCES citys(id) ON DELETE CASCADE 


) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


    city_id INT ,
    FOREIGN KEY (city_id) REFERENCES citys(id) ON DELETE CASCADE 



CREATE TABLE logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_type VARCHAR(200) NOT NULL, 
    table_id INT ,
    user_type ENUM('emp','cstm') NOT NULL,
    user_id INT ,
    dt DATETIME DEFAULT CURRENT_TIMESTAMP,
    note TEXT DEFAULT NULL,
    log_type ENUM('edit','add','del') NOT NULL

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `funds` (
    `id` int(11) NOT NULL,
    `name` varchar(100) NOT NULL,
    `acc_num` varchar(100) NOT NULL,
    `is_active` tinyint(1) NOT NULL DEFAULT 1,
    `note` VARCHAR(500) DEFAULT NULL,
    `py_ty` enum('cash','card','bank','transfer','other') DEFAULT 'cash'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


ALTER TABLE `funds`
    ADD PRIMARY KEY (`id`),
    ADD UNIQUE KEY `name` (`name`);


CREATE TABLE coins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL,
    name VARCHAR(100) UNIQUE NOT NULL,
    icon VARCHAR(10) ,
    is_main tinyint(1) NOT NULL DEFAULT 0,
    sts ENUM('ok','sale','buy','stop') NOT NULL DEFAULT 'ok'
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE coin_chng (
    id INT AUTO_INCREMENT PRIMARY KEY,
    from_coin_id INT NOT NULL,
    to_coin_id INT NOT NULL,
    price DOUBLE DEFAULT NULL, 
    dt_start DATETIME DEFAULT CURRENT_TIMESTAMP,
    dt_end DATETIME DEFAULT NULL,
    is_active tinyint(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (from_coin_id) REFERENCES coins(id) ON DELETE CASCADE ,
    FOREIGN KEY (to_coin_id) REFERENCES coins(id) ON DELETE CASCADE 

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



CREATE TABLE fund_monys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fund_id INT NOT NULL, 
    coin_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    sts ENUM('stop','ok','stop_in','stop_out') NOT NULL DEFAULT 'ok' ,
    FOREIGN KEY (fund_id) REFERENCES funds(id) ON DELETE CASCADE ,
    FOREIGN KEY (coin_id) REFERENCES coins(id) ON DELETE CASCADE 


)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;





CREATE TABLE person_monys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cstm_id INT NOT NULL, 
    coin_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    sts ENUM('stop','ok','stop_in','stop_out') NOT NULL DEFAULT 'ok' ,
    FOREIGN KEY (cstm_id) REFERENCES cstms(id) ON DELETE CASCADE ,
    FOREIGN KEY (coin_id) REFERENCES coins(id) ON DELETE CASCADE 


)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;






CREATE TABLE ptypes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE genders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name ENUM('male','female','all')
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE colors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(500) ,
    color_code VARCHAR(500)

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE sizes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name ENUM('XXS','XS','S','M','L','XL','XXL','XXXL','A')
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE pdts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ptype_id INT NOT NULL,
    gender_id INT ,
    seller_id INT NOT NULL,
    city_id INT ,
    name VARCHAR(150) NOT NULL,
    my_rate DECIMAL(10,2) NOT NULL,
    rtr_hours INT NOT NULL DEFAULT 0,
    note TEXT DEFAULT NULL,
    sts ENUM('ok','end','stop','del') NOT NULL DEFAULT 'ok',
    FOREIGN KEY (ptype_id) REFERENCES ptype(id) ON DELETE CASCADE,
    FOREIGN KEY (gender_id) REFERENCES genders(id) ON DELETE CASCADE,
    FOREIGN KEY (seller_id) REFERENCES cstms(id) ON DELETE CASCADE,
    FOREIGN KEY (city_id) REFERENCES citys(id) ON DELETE CASCADE 
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE pdt_sizes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    size_id INT ,
    color_id INT ,
    pdt_id INT ,
    price DECIMAL(10,2) NOT NULL,
    coin_id INT NOT NULL,
    qty INT NOT NULL DEFAULT 0,
    note TEXT DEFAULT NULL,
    sts ENUM('ok','end','stop','del') NOT NULL DEFAULT 'ok',
    FOREIGN KEY (size_id) REFERENCES sizes(id) ON DELETE CASCADE,
    FOREIGN KEY (coin_id) REFERENCES coins(id) ON DELETE CASCADE,
    FOREIGN KEY (color_id) REFERENCES colors(id) ON DELETE CASCADE,
    FOREIGN KEY (pdt_id) REFERENCES pdts(id) ON DELETE CASCADE 
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    inv_num VARCHAR(100) DEFAULT NULL,
    buyer_id INT NOT NULL,
    seller_id INT NULL,
    coin_id INT NOT NULL,
    dt DATETIME DEFAULT CURRENT_TIMESTAMP,
    amount DECIMAL(10,2) NOT NULL,
    paid DECIMAL(10,2) NOT NULL,
    note TEXT DEFAULT NULL,
    sts ENUM('ok','del','wait','agree','no','draft','procssing','sent') NOT NULL DEFAULT 'ok',
    check_dt DATETIME DEFAULT NULL,
    check_note TEXT DEFAULT NULL ,  

    FOREIGN KEY (seller_id) REFERENCES cstms(id) ON DELETE CASCADE,
    FOREIGN KEY (buyer_id) REFERENCES cstms(id) ON DELETE CASCADE,
    FOREIGN KEY (coin_id) REFERENCES coins(id) ON DELETE CASCADE

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE sale_itms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sale_id INT NOT NULL,
    pdt_id INT NOT NULL,
    color_id INT NOT NULL,
    size_id INT NOT NULL,
    coin_id INT NOT NULL,
    qty INT NOT NULL,
    one_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
    FOREIGN KEY (size_id) REFERENCES sizes(id) ON DELETE CASCADE,
    FOREIGN KEY (coin_id) REFERENCES coins(id) ON DELETE CASCADE,
    FOREIGN KEY (color_id) REFERENCES colors(id) ON DELETE CASCADE,
    FOREIGN KEY (pdt_id) REFERENCES pdts(id) ON DELETE CASCADE 

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE sale_rtr (
    id INT AUTO_INCREMENT PRIMARY KEY,
    coin_id INT NOT NULL,  
    buyer_id INT NOT NULL,
    seller_id INT NULL,             
    dt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    amount DECIMAL(10,2) NOT NULL,          
    paid DECIMAL(10,2) NOT NULL,          
    note TEXT DEFAULT NULL,
    sts ENUM('ok','del','wait','agree','no','draft','procssing','sent') NOT NULL DEFAULT 'ok',
    check_dt DATETIME DEFAULT NULL,
    check_note TEXT DEFAULT NULL,
    FOREIGN KEY (seller_id) REFERENCES cstms(id) ON DELETE CASCADE,
    FOREIGN KEY (buyer_id) REFERENCES cstms(id) ON DELETE CASCADE,
    FOREIGN KEY (coin_id) REFERENCES coins(id) ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE sale_rtr_itms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sale_rtr_id INT NOT NULL,
    sale_itms_id INT NOT NULL,           
    qty INT NOT NULL

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE bag (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cstm_id INT ,
    act ENUM('bag','like'),
    qty INT NOT NULL DEFAULT 1 ,
    pdt_id INT NOT NULL,
    color_id INT NOT NULL,
    size_id INT NOT NULL,
    dt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (size_id) REFERENCES sizes(id) ON DELETE CASCADE,
    FOREIGN KEY (color_id) REFERENCES colors(id) ON DELETE CASCADE,
    FOREIGN KEY (pdt_id) REFERENCES pdts(id) ON DELETE CASCADE 


)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
  

CREATE TABLE skips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(200) NOT NULL,
    col_id INT NOT NULL,
    user_id INT ,
    skip_type ENUM('all','only_error')
    dt DATETIME DEFAULT CURRENT_TIMESTAMP,
    why TEXT DEFAULT NULL,
    note TEXT DEFAULT NULL

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
  
CREATE TABLE phone_numbers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(200) NOT NULL,
    col_id INT NOT NULL,
    phone VARCHAR(100) NOT NULL,
    phone_type ENUM('static','mobile') NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

  
CREATE TABLE images_and_files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(200) NOT NULL,
    img_type ENUM('primary','secondary','extra') NOT NULL,
    file_name TEXT NOT NULL, 
    file_extension VARCHAR(200) NOT NULL, 
    is_active TINYINT(1) NOT NULL DEFAULT 1

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
  
