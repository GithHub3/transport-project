-- ⚙️ إعداد ضروري
SET NAMES utf8mb4; SET time_zone = '+03:00';




CREATE TABLE IF NOT EXISTS users (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  fullname        VARCHAR(100) NOT NULL,
  username        VARCHAR(100) NOT NULL UNIQUE,
  pass         VARCHAR(255) NOT NULL,
  phone        VARCHAR(100) ,
  email        VARCHAR(100) ,
  user_type ENUM('admin','finance','prodect_manager','support') NOT NULL,

  status ENUM('ok','stop','delete') NOT NULL DEFAULT 'ok'

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;




CREATE TABLE IF NOT EXISTS users_cstm (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  fullname        VARCHAR(100) NOT NULL,
  username        VARCHAR(100) NOT NULL UNIQUE,
  pass         VARCHAR(255) NOT NULL,
  phone        VARCHAR(100) ,
  email        VARCHAR(100) ,
  address TEXT ,
  location_url TEXT ,
  user_type ENUM('seller','buyer') NOT NULL DEFAULT 'buyer',
  check_code VARCHAR(100) ,
  status ENUM('ok','stop','delete','on_check') NOT NULL 

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



