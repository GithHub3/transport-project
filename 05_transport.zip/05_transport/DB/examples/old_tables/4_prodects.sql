
-- emplooes







-- Categories
CREATE TABLE ptype (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Products
CREATE TABLE pdts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ptype_id INT NOT NULL,
    seller_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    pdt_count INT NOT NULL DEFAULT 0,
    price DECIMAL(10,2) NOT NULL,
    coin_id INT NOT NULL,
    my_rate DECIMAL(10,2) NOT NULL,
    rtr_hours INT NOT NULL DEFAULT 0,
    note TEXT DEFAULT NULL,
    sts ENUM('ok','sale','buy','stop') NOT NULL DEFAULT 'ok',
    FOREIGN KEY (ptype_id) REFERENCES ptype(id) ON DELETE SET NULL,
    FOREIGN KEY (coin_id) REFERENCES coins(id) ON DELETE SET NULL,
    FOREIGN KEY (seller_id) REFERENCES users_cstm(id) ON DELETE SET NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

