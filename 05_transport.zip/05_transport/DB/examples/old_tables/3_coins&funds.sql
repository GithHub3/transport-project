


--
-- بنية الجدول `funds`
--

CREATE TABLE `funds` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `acc_num` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `note` VARCHAR(500) DEFAULT NULL
  `py_ty` enum('cash','card','bank','transfer','other') DEFAULT 'cash'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


ALTER TABLE `funds`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);


--
-- Indexes for dumped tables
--

--
-- Indexes for table `fund_user_permissions`

CREATE TABLE coins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL,
    name VARCHAR(100) UNIQUE NOT NULL,
    icon VARCHAR(10) ,
    is_main tinyint(1) NOT NULL DEFAULT 0,
    sts ENUM('ok','sale','buy','stop') NOT NULL DEFAULT 'ok'
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS users (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  fullname        VARCHAR(100) NOT NULL,
  username        VARCHAR(100) NOT NULL UNIQUE,
  pass         VARCHAR(255) NOT NULL,
  phone        VARCHAR(100) ,
  email        VARCHAR(100) ,
  user_type ENUM('admin','finance','prodect_manager','support') NOT NULL,

  status ENUM('ok','stop','delete') NOT NULL DEFAULT 'ok'

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- coin_chng
CREATE TABLE coin_chng (
    id INT AUTO_INCREMENT PRIMARY KEY,
    from_coin_id INT NOT NULL,
    to_coin_id INT NOT NULL,
    price DOUBLE DEFAULT NULL, 
    dt_start DATETIME DEFAULT CURRENT_TIMESTAMP,
    dt_end DATETIME DEFAULT NULL,

    is_active tinyint(1) NOT NULL DEFAULT 0

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



CREATE TABLE fund_monys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fund_id INT NOT NULL, 
    coin_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    sts ENUM('stop','ok','stop_in','stop_out') NOT NULL DEFAULT 'ok'

)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;





CREATE TABLE person_monys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    psn_type ENUM('emps','cstm') NOT NULL,
    psn_id INT NOT NULL, 
    coin_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    sts ENUM('stop','ok','stop_in','stop_out') NOT NULL DEFAULT 'ok'


)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




