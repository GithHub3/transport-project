-- إدخال الدول (اليمن وأمريكا)
INSERT INTO countrys (id, name_ar, name_en, code, note) VALUES
(1, 'اليمن', 'Yemen', 'YE', NULL),
(2, 'الولايات المتحدة الأمريكية', 'United States', 'US', NULL);

-- إدخال المحافظات اليمنية (تابعة للدولة رقم 1)
INSERT INTO states (country_id, name_ar, name_en, code, note) VALUES
(1, 'أبين', 'Abyan', 'AB', NULL),
(1, 'عدن', 'Aden', 'AD', NULL),
(1, 'الضالع', 'Ad Dali''', 'DA', NULL),
(1, 'البيضاء', 'Al Bayda''', 'BA', NULL),
(1, 'الحديدة', 'Al Hudaydah', 'HU', NULL),
(1, 'الجوف', 'Al Jawf', 'JA', NULL),
(1, 'المهرة', 'Al Mahrah', 'MR', NULL),
(1, 'المحويت', 'Al Mahwit', 'MW', NULL),
(1, 'أرخبيل سقطرى', 'Socotra', 'SU', NULL),
(1, 'عمران', 'Amran', 'AM', NULL),
(1, 'ذمار', 'Dhamar', 'DH', NULL),
(1, 'حضرموت', 'Hadramawt', 'HD', NULL),
(1, 'حجة', 'Hajjah', 'HJ', NULL),
(1, 'إب', 'Ibb', 'IB', NULL),
(1, 'لحج', 'Lahij', 'LA', NULL),
(1, 'مأرب', 'Ma''rib', 'MA', NULL),
(1, 'ريمة', 'Raymah', 'RA', NULL),
(1, 'صعدة', 'Sa''dah', 'SD', NULL),
(1, 'صنعاء', 'Sana''a', 'SN', NULL),
(1, 'شبوة', 'Shabwah', 'SH', NULL),
(1, 'تعز', 'Ta''izz', 'TA', NULL),
(1, 'أمانة العاصمة', 'Amanat Al Asimah', 'SA', NULL);

-- إدخال الولايات الأمريكية (تابعة للدولة رقم 2)
INSERT INTO states (country_id, name_ar, name_en, code, note) VALUES
(2, 'ألاباما', 'Alabama', 'AL', NULL),
(2, 'ألاسكا', 'Alaska', 'AK', NULL),
(2, 'أريزونا', 'Arizona', 'AZ', NULL),
(2, 'أركنساس', 'Arkansas', 'AR', NULL),
(2, 'كاليفورنيا', 'California', 'CA', NULL),
(2, 'كولورادو', 'Colorado', 'CO', NULL),
(2, 'كونيتيكت', 'Connecticut', 'CT', NULL),
(2, 'ديلاوير', 'Delaware', 'DE', NULL),
(2, 'فلوريدا', 'Florida', 'FL', NULL),
(2, 'جورجيا', 'Georgia', 'GA', NULL),
(2, 'هاواي', 'Hawaii', 'HI', NULL),
(2, 'أيداهو', 'Idaho', 'ID', NULL),
(2, 'إلينوي', 'Illinois', 'IL', NULL),
(2, 'إنديانا', 'Indiana', 'IN', NULL),
(2, 'آيوا', 'Iowa', 'IA', NULL),
(2, 'كانساس', 'Kansas', 'KS', NULL),
(2, 'كنتاكي', 'Kentucky', 'KY', NULL),
(2, 'لويزيانا', 'Louisiana', 'LA', NULL),
(2, 'مين', 'Maine', 'ME', NULL),
(2, 'ميريلاند', 'Maryland', 'MD', NULL),
(2, 'ماساتشوستس', 'Massachusetts', 'MA', NULL),
(2, 'ميشيغان', 'Michigan', 'MI', NULL),
(2, 'مينيسوتا', 'Minnesota', 'MN', NULL),
(2, 'مسيسيبي', 'Mississippi', 'MS', NULL),
(2, 'ميزوري', 'Missouri', 'MO', NULL),
(2, 'مونتانا', 'Montana', 'MT', NULL),
(2, 'نبراسكا', 'Nebraska', 'NE', NULL),
(2, 'نيفادا', 'Nevada', 'NV', NULL),
(2, 'نيوهامبشير', 'New Hampshire', 'NH', NULL),
(2, 'نيو جيرسي', 'New Jersey', 'NJ', NULL),
(2, 'نيو مكسيكو', 'New Mexico', 'NM', NULL),
(2, 'نيويورك', 'New York', 'NY', NULL),
(2, 'كارولاينا الشمالية', 'North Carolina', 'NC', NULL),
(2, 'داكوتا الشمالية', 'North Dakota', 'ND', NULL),
(2, 'أوهايو', 'Ohio', 'OH', NULL),
(2, 'أوكلاهوما', 'Oklahoma', 'OK', NULL),
(2, 'أوريغون', 'Oregon', 'OR', NULL),
(2, 'بنسيلفانيا', 'Pennsylvania', 'PA', NULL),
(2, 'رود آيلاند', 'Rhode Island', 'RI', NULL),
(2, 'كارولاينا الجنوبية', 'South Carolina', 'SC', NULL),
(2, 'داكوتا الجنوبية', 'South Dakota', 'SD', NULL),
(2, 'تينيسي', 'Tennessee', 'TN', NULL),
(2, 'تكساس', 'Texas', 'TX', NULL),
(2, 'يوتا', 'Utah', 'UT', NULL),
(2, 'فيرمونت', 'Vermont', 'VT', NULL),
(2, 'فرجينيا', 'Virginia', 'VA', NULL),
(2, 'واشنطن', 'Washington', 'WA', NULL),
(2, 'فرجينيا الغربية', 'West Virginia', 'WV', NULL),
(2, 'ويسكونسن', 'Wisconsin', 'WI', NULL),
(2, 'وايومنغ', 'Wyoming', 'WY', NULL);


INSERT INTO states (country_id, name_ar, name_en, code, note) VALUES
(2, 'واشنطن العاصمة', 'District of Columbia', 'DC', NULL),
(2, 'بورتوريكو', 'Puerto Rico', 'PR', NULL),
(2, 'غوام', 'Guam', 'GU', NULL),
(2, 'ساموا الأمريكية', 'American Samoa', 'AS', NULL),
(2, 'جزر ماريانا الشمالية', 'Northern Mariana Islands', 'MP', NULL),
(2, 'جزر العذراء الأمريكية', 'U.S. Virgin Islands', 'VI', NULL);



