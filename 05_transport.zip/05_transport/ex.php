
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(100) NOT NULL,
    username VARCHAR(100) NOT NULL UNIQUE,
    pass VARCHAR(255) NOT NULL,
    phone VARCHAR(100),
    email VARCHAR(100),
    check_code VARCHAR(100),
    sts ENUM('ok','stop','delete','on_check') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



CREATE TABLE user_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(64) NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_token (user_id, token)
);


CREATE TABLE perms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(500) NOT NULL,
    code VARCHAR(100) NOT NULL
);
CREATE TABLE user_perms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    perm_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (perm_id) REFERENCES perms(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_perm (user_id, perm_id)
);
<?php
// بعد التحقق من صحة بيانات الدخول
if ($login_success) {
    // بدء الجلسة
    session_start();
    $_SESSION['user_id'] = $user_id;
    
    // إذا تم تحديد "تذكرني"
    if (isset($_POST['remember_me']) && $_POST['remember_me'] == '1') {
        // إنشاء رمز عشوائي بطول 64 حرفًا (مثلاً)
        $token = bin2hex(random_bytes(32)); // 64 حرفًا hex
        
        // مدة الصلاحية (مثلاً 30 يومًا)
        $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
        
        // تخزين الرمز في قاعدة البيانات
        $stmt = $pdo->prepare("INSERT INTO user_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $token, $expires]);
        
        // وضع الكوكي في المتصفح (آمن، HttpOnly، SameSite)
        setcookie(
            'remember_me',           // اسم الكوكي
            $token,                  // القيمة
            strtotime('+30 days'),    // انتهاء الصلاحية (ثواني)
            '/',                      // المسار
            '',                       // المجال (اختياري)
            true,                     // Secure (لـ HTTPS)
            true                      // HttpOnly
        );
    }
    
    // توجيه المستخدم إلى الصفحة الرئيسية
    header('Location: dashboard.php');
    exit;
}

session_start();

// إذا لم تكن الجلسة موجودة، تحقق من كوكي remember_me
if (!isset($_SESSION['user_id']) && isset($_COOKIE['remember_me'])) {
    $token = $_COOKIE['remember_me'];
    
    // البحث عن الرمز في قاعدة البيانات
    $stmt = $pdo->prepare("SELECT user_id, expires_at FROM user_tokens WHERE token = ?");
    $stmt->execute([$token]);
    $row = $stmt->fetch();
    
    if ($row) {
        // التحقق من أن الرمز لم ينتهِ صلاحيته
        if (strtotime($row['expires_at']) > time()) {
            // تسجيل الدخول التلقائي
            $_SESSION['user_id'] = $row['user_id'];
            
            // (اختياري) تجديد الرمز لتعزيز الأمان - إنشاء رمز جديد وحذف القديم
            $new_token = bin2hex(random_bytes(32));
            $new_expires = date('Y-m-d H:i:s', strtotime('+30 days'));
            
            // تحديث الجدول بالرمز الجديد
            $update = $pdo->prepare("UPDATE user_tokens SET token = ?, expires_at = ? WHERE token = ?");
            $update->execute([$new_token, $new_expires, $token]);
            
            // تحديث الكوكي بالرمز الجديد
            setcookie('remember_me', $new_token, strtotime('+30 days'), '/', '', true, true);
        } else {
            // الرمز منتهي الصلاحية: حذفه من قاعدة البيانات والكوكي
            $pdo->prepare("DELETE FROM user_tokens WHERE token = ?")->execute([$token]);
            setcookie('remember_me', '', time() - 3600, '/'); // حذف الكوكي
        }
    } else {
        // رمز غير موجود: حذف الكوكي
        setcookie('remember_me', '', time() - 3600, '/');
    }
}


// في صفحة logout.php
session_start();

if (isset($_SESSION['user_id']) && isset($_COOKIE['remember_me'])) {
    $token = $_COOKIE['remember_me'];
    // حذف الرمز من قاعدة البيانات
    $pdo->prepare("DELETE FROM user_tokens WHERE token = ?")->execute([$token]);
}

// إزالة الكوكي
setcookie('remember_me', '', time() - 3600, '/');

// تدمير الجلسة
session_destroy();
header('Location: login.php');
exit;