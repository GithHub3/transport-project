<?php
define('BASE_PATH', realpath(__DIR__)); // المسار الكامل للملفات PHP
define('BASE_URL', 'http://localhost:8083/00_my_projects/05_transport'); // رابط الموقع المحلي

define('LIBS_PATH', BASE_PATH . '/libs');
define('LIBS', BASE_PATH . '/libs');
define('LIBS_URL', BASE_URL . '/libs');
define('SEC_PATH', LIBS_PATH . '/security');
define('MY_LIBS', LIBS_PATH . '/my_libs');
define('CRUD_PATH', LIBS_PATH . '/query/help_fun.php');
define('EMAIL_PATH', LIBS_PATH . '/php_help/send_email/email.php');
// D:\xampp\htdocs\00_my_projects\02_online_shop\libs\query\help_fun.php
// D:\xampp\htdocs\00_my_projects\02_online_shop\libs\php_help\send_email\email.php

define('APP_PATH', BASE_PATH . '/app');
define('LYT_PATH', APP_PATH . '/layouts');
define('PAGES_PATH', APP_PATH . '/pages');

define('APP_URL', BASE_URL . '/app');
define('PAGES_URL', APP_URL . '/pages');


define('ALL_ASTS', BASE_URL . '/assets');

define('TEMP_ASTS', ALL_ASTS . '/temp_assets');
define('TEMP_CSS', TEMP_ASTS . '/css');
define('TEMP_JS', TEMP_ASTS . '/js');
define('TEMP_IMGS', BASE_PATH . '/assets/temp_assets/images');
define('TEMP_IMGS_URL', TEMP_ASTS . '/images');

define('MY_ASTS', ALL_ASTS . '/my_assets');
define('MY_CSS', MY_ASTS . '/css');
define('MY_JS', MY_ASTS . '/js');
define('MY_IMGS', BASE_URL . '/assets/temp_assets/images');




?>

