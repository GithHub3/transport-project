<?php

/**
 * ملف إرسال البريد الإلكتروني باستخدام PHPMailer
 * يجب تثبيت مكتبة PHPMailer أولاً عبر Composer أو تحميلها يدوياً
 * تحميل: https://github.com/PHPMailer/PHPMailer
 */

// استدعاء ملفات PHPMailer (عدل المسار حسب مكان تخزين المكتبة)
require_once __DIR__ . '/PHPMailer/src/Exception.php';
require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * دالة إرسال البريد الإلكتروني عبر Gmail SMTP
 * 
 * @param string $user_email البريد الإلكتروني للمستقبل
 * @param string $msg_title عنوان الرسالة
 * @param string $msg محتوى الرسالة (يمكن أن يكون HTML)
 * @return int 1 عند النجاح، 0 عند الفشل
 */
function EmailSend($user_email, $msg_title, $msg)
{
    // إنشاء كائن PHPMailer مع تفعيل الاستثناءات
    $mail = new PHPMailer(true);

    try {
        // إعدادات SMTP لخادم Gmail
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';                 // خادم Gmail SMTP
        $mail->SMTPAuth   = true;                              // تفعيل المصادقة
        $mail->Username   = 'ghithfuaad@gmail.com';    // بريدك الإلكتروني
        $mail->Password   = 'dlkgaqtaplqwlpik';                // كلمة مرور التطبيق (بدون مسافات)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;    // التشفير (TLS)
        $mail->Port       = 587;                               // منفذ TLS

        // إعدادات المرسل والمستقبل
        $mail->setFrom('bastah0shop@gmail.com', 'bastah'); // الاسم يظهر للمستلم
        $mail->addAddress($user_email);                        // أضف المستلم

        // محتوى الرسالة
        $mail->isHTML(true);                                    // تفعيل HTML
        $mail->Subject = $msg_title;
        $mail->Body    = $msg;
        $mail->AltBody = strip_tags($msg);                     // نسخة نصية للإيميلات القديمة

        // إرسال البريد
        $mail->send();
        return 1; // نجاح
    } catch (Exception $e) {
        // في حالة الخطأ يمكن تسجيل التفاصيل (اختياري)
        // error_log("فشل إرسال البريد: " . $mail->ErrorInfo);
        return 0; // فشل
    }
}

function EmailCode($user_email, $check_code)
{
    $msg =  "<h1>تأكيد البريد الإلكتروني</h1> <h3> ".$check_code." </h3> <p>شكراً لتسجيلك معنا.</p>";

    // إنشاء كائن PHPMailer مع تفعيل الاستثناءات
    $mail = new PHPMailer(true);


    try {
        // إعدادات SMTP لخادم Gmail
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';                 // خادم Gmail SMTP
        $mail->SMTPAuth   = true;                              // تفعيل المصادقة
        $mail->Username   = 'ghithfuaad@gmail.com';    // بريدك الإلكتروني
        $mail->Password   = 'dlkgaqtaplqwlpik';                // كلمة مرور التطبيق (بدون مسافات)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;    // التشفير (TLS)
        $mail->Port       = 587;                               // منفذ TLS

        // إعدادات المرسل والمستقبل
        $mail->setFrom('bastah0shop@gmail.com', 'bastah'); // الاسم يظهر للمستلم
        $mail->addAddress($user_email);                        // أضف المستلم

        // محتوى الرسالة
        $mail->isHTML(true);                                    // تفعيل HTML
        $mail->Subject = "Check Code";
        $mail->Body    = $msg;
        $mail->AltBody = strip_tags($msg);                     // نسخة نصية للإيميلات القديمة

        // إرسال البريد
        $mail->send();
        return 1; // نجاح
    } catch (Exception $e) {
        // في حالة الخطأ يمكن تسجيل التفاصيل (اختياري)
        // error_log("فشل إرسال البريد: " . $mail->ErrorInfo);
        return 0; // فشل
    }
}


// ---------- مثال للاستخدام ----------
// قم بتجريب الدالة مباشرة (يمكنك تعليق هذه الأسطر بعد التأكد من العمل)
/*
$result = EmailSend(
    "aalsiadi33@gmail.com",
    "Check Code",
    "<h1>تأكيد البريد الإلكتروني</h1>
    <h3> fdjksfoie </h3>
    <p>شكراً لتسجيلك معنا.</p>"
);

if ($result == 1) {
    echo "تم إرسال البريد بنجاح";
} else {
    echo "حدث خطأ أثناء الإرسال";
}

*/

/*
$result = EmailCode("aalsiadi33@gmail.com","02543");

if ($result == 1) {
    echo "تم إرسال البريد بنجاح";
} else {
    echo "حدث خطأ أثناء الإرسال";
}
*/


