<?php 


function randomCode($length = 16) {
    $bytes = random_bytes(ceil($length / 2)); // كل 2 حرف hex = 1 بايت
    return substr(bin2hex($bytes), 0, $length);
}

// echo randomCode(21);
// D:\xampp\htdocs\00_my_projects\02_online_shop\libs\php_help\my_fun.php



