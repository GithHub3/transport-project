<?php
require_once 'help_fun.php';

$crud = new CRUD();

// مثال على الإضافة
$userData = [
    'name' => 'أحمد',
    'email' => 'ahmed@example.com',
    'age' => 25
];
$crud->insert('users', $userData);

// مثال على التحديث
$updateData = ['age' => 26];
$conditions = ['email' => 'ahmed@example.com'];
$crud->update('users', $updateData, $conditions);

// مثال على الحذف
$crud->delete('users', ['email' => 'ahmed@example.com']);

// مثال على الاستدعاء بجميع السجلات
$allUsers = $crud->select('users');

// مثال على الاستدعاء بشروط
$youngUsers = $crud->select('users', '*', ['age' => 25], 'name ASC', '10');

// مثال على استدعاء سجل واحد
$user = $crud->selectOne('users', '*', ['email' => 'ahmed@example.com']);

// مثال على العد
$userCount = $crud->count('users', ['age' => 25]);
?>