<?php 


class RoomsView {

    public $roomTypes = [
        'suit' => 'جناح',
        'apartment' => 'شقة',
        'room' => 'غرفة',
        'seat' => 'مجلس',
        'mana' => 'طيرمانه',
        'tent' => 'خيمة'
    ];
    public $roomColors = [
        'empty' => 'st-empty',
        'serv' => 'st-pur',
        'clean' => 'st-sky',
        'paid' => 'st-green',
        'not_paid' => 'st-red',
        'is_warning' => 'st-yellow'
        
    ];



     public function headSuit($type, $suitNumber ,$suit_id  ,$color,$note="") {
      
        echo '
      
            <div onclick="window.location.href=\'page.php?id='.$suit_id.' \';" style="cursor: pointer;" class="cell '.$this->roomColors[$color].' ">
            <div class="top">
              <span> ' . $this->roomTypes[$type] . ' </span>
              <span>' . $suitNumber . '<span class="badge-dot"></span>
              </span>
            </div>

            <div class="container p-1">
            <div class="row g-2">
        ';
    }



     public function footSuit($price) {
      
        echo '
       
            </div>
            </div>




            <div class="price">' . $price . '</div>
            </div>
        ';
    }






     public function roomBox($type, $roomNumber, $room_id ,$color ,$note="",$gname="",$wc = 0 ,$single_beds =0 ,$couple_beds=0 ,$price ) {
      
        echo '
          <div class="col"> 

     <!-- بطاقة الغرفة -->
        <div onclick="window.location.href=\'page.php?id='.$room_id.' \';" style="cursor: pointer;" class="room-card-2 '.$this->roomColors[$color].' ">
            <div class="top">
              <span>' . $this->roomTypes[$type] . '</span>
              <span>'. $roomNumber .'<span class="badge-dot"></span></span>
            </div>
     
            <div class="guest-name-2">'.$gname.'</div>
            <div class="price-2">'.$price.'</div>
        </div>

    </div>

         
        ';
    }


}











?>