<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config.php';
require_once MY_LIBS . '/lib_invoice.php';
try {
    $crud = new CRUD();
    $pdo = db_conn();
    $type = clean_str($_POST['type'] ?? '');
    $id = clean_int($_POST['id'] ?? null);

    if (!$id || !$type) {
        throw new RuntimeException('بيانات الحذف غير مكتملة.');
    }

    $pdo->beginTransaction();

    if ($type === 'item') {
        delete_classes_by_item_id($pdo, $id);
        $crud->delete('cstm_items', ['id' => $id]);
    } elseif ($type === 'class') {
        delete_parts_by_class_id($pdo, $id);
        $crud->delete('item_classes', ['id' => $id]);
    } elseif ($type === 'part') {
        $crud->delete('class_parts', ['id' => $id]);
    } else {
        throw new RuntimeException('نوع الحذف غير مدعوم.');
    }

    $pdo->commit();
    echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
