<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config.php';
require_once MY_LIBS . '/lib_invoice.php';


$unitType='';
$m3Sums =0;
$kgSums =0;
function insert_customer_if_needed(CRUD $crud, array $new, $existingId, array &$errors, $label) {
    $existingId = clean_int($existingId);
    if ($existingId) {
        return $existingId;
    }

    $nameAr = clean_str($new['name_ar'] ?? '');
    $nameEn = clean_str($new['name_en'] ?? '');
    if ($nameAr === '' && $nameEn === '') {
        $errors[] = "{$label}: اختر عميلاً موجوداً أو أدخل بيانات عميل جديد.";
        return null;
    }

    $data = [
        'state_id' => clean_int($new['state_id'] ?? null),
        'name_ar' => $nameAr ?: null,
        'name_en' => $nameEn ?: null,
        'email' => clean_str($new['email'] ?? '') ?: null,
        'phone1' => clean_str($new['phone1'] ?? '') ?: null,
        'phone2' => clean_str($new['phone2'] ?? '') ?: null,
        'address' => clean_str($new['address'] ?? '') ?: null,
        'location' => clean_str($new['location'] ?? '') ?: null,
    ];

    return $crud->insertId('cstms', $data);
}

try {
    $pdo = db_conn();
    $crud = new CRUD();
    $errors = [];

    $id = clean_int($_POST['id'] ?? null);
    $stateIdFrom = clean_int($_POST['state_id_from'] ?? null);
    $stateIdTo = clean_int($_POST['state_id_to'] ?? null);

    if (!$stateIdFrom) {
        $errors[] = 'اختر الولاية من state_id_from.';
    }
    if (!$stateIdTo) {
        $errors[] = 'اختر الولاية من state_id_to.';
    }

    $nested = json_decode($_POST['nested_data'] ?? '[]', true);
    if (!is_array($nested) || !$nested) {
        $errors[] = 'أضف عنصراً واحداً على الأقل.';
    }

    $cstmIdSend = insert_customer_if_needed($crud, $_POST['send_new'] ?? [], $_POST['cstm_id_send'] ?? null, $errors, 'المرسل');
    $cstmIdReceive = insert_customer_if_needed($crud, $_POST['receive_new'] ?? [], $_POST['cstm_id_receive'] ?? null, $errors, 'المستلم');

    if ($errors) {
        echo json_encode(['success' => false, 'message' => implode("\n", $errors)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $pdo->beginTransaction();

    $invData = [
        'ship_id' => clean_int($_POST['ship_id'] ?? null),
        'cstm_id_send' => $cstmIdSend,
        'cstm_id_receive' => $cstmIdReceive,
        'state_id_from' => $stateIdFrom,
        'state_id_to' => $stateIdTo,
        'coin_id' => clean_int($_POST['coin_id'] ?? null),
        'inv_num' => clean_str($_POST['inv_num'] ?? '') ?: null,
        'dt' => to_datetime_or_now($_POST['dt'] ?? ''),
        'amount' => clean_num($_POST['amount'] ?? 0),
        'paid' => clean_num($_POST['paid'] ?? 0),
        'note' => clean_str($_POST['note'] ?? '') ?: null,
    ];

    if ($id) {
        $exists = $crud->selectOne('cstm_inv', '*', ['id' => $id]);
        if (!$exists) {
            throw new RuntimeException('الفاتورة غير موجودة.');
        }
        if (!$crud->update('cstm_inv', $invData, ['id' => $id])) {
            throw new RuntimeException('فشل تحديث الفاتورة.');
        }
        $invoiceId = $id;
    } else {
        $invoiceId = $crud->insertId('cstm_inv', $invData);
        if (!$invoiceId) {
            throw new RuntimeException('فشل إنشاء الفاتورة.');
        }
    }

    $existingItemIds = [];
    $existingClassIds = [];
    $existingPartIds = [];

    if ($invoiceId) {
        $stmt = $pdo->prepare("SELECT id FROM cstm_items WHERE cstm_inv_id = :id");
        $stmt->execute(['id' => $invoiceId]);
        $existingItemIds = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN) ?: []);

        if ($existingItemIds) {
            $placeholders = implode(',', array_fill(0, count($existingItemIds), '?'));
            $stmt = $pdo->prepare("SELECT id FROM item_classes WHERE item_id IN ($placeholders)");
            $stmt->execute($existingItemIds);
            $existingClassIds = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN) ?: []);

            if ($existingClassIds) {
                $placeholders = implode(',', array_fill(0, count($existingClassIds), '?'));
                $stmt = $pdo->prepare("SELECT id FROM class_parts WHERE class_id IN ($placeholders)");
                $stmt->execute($existingClassIds);
                $existingPartIds = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN) ?: []);
            }
        }
    }

    $submittedItemIds = [];
    $submittedClassIds = [];
    $submittedPartIds = [];

    foreach ($nested as $item) {
        $itemData = [
            'cstm_inv_id' => $invoiceId,
            // 'coin_id' => clean_int($item['coin_id'] ?? null),
            // 'inv_num' => clean_str($item['inv_num'] ?? '') ?: null,
            'name_ar' => clean_str($item['name_ar'] ?? '') ?: null,
            'name_en' => clean_str($item['name_en'] ?? '') ?: null,
            // 'dt' => to_datetime_or_now($item['dt'] ?? ''),
            // 'amount' => clean_num($item['amount'] ?? 0),
            // 'paid' => clean_num($item['paid'] ?? 0),
            'note' => clean_str($item['note'] ?? '') ?: null,
        ];

        $itemId = clean_int($item['id'] ?? null);
        if ($itemId && in_array($itemId, $existingItemIds, true)) {
            if (!$crud->update('cstm_items', $itemData, ['id' => $itemId])) {
                throw new RuntimeException('فشل تحديث عنصر فاتورة.');
            }
        } else {
            $itemId = $crud->insertId('cstm_items', $itemData);
            if (!$itemId) {
                throw new RuntimeException('فشل إضافة عنصر فاتورة.');
            }
        }
        $submittedItemIds[] = (int)$itemId;

        foreach (($item['classes'] ?? []) as $class) {
            $unit = clean_str($class['unit'] ?? 'm3');
            if (!in_array($unit, ['m3', 'kg'], true)) {
                $unit = 'm3';
            }
            $classData = [
                'item_id' => $itemId,
                'name_ar' => clean_str($class['name_ar'] ?? '') ?: null,
                'name_en' => clean_str($class['name_en'] ?? '') ?: null,
                'unit' => $unit,
                'note' => clean_str($class['note'] ?? '') ?: null,
            ];
            // unit
            $unitType = $unit;
            // __

            $classId = clean_int($class['id'] ?? null);
            if ($classId && in_array($classId, $existingClassIds, true)) {
                if (!$crud->update('item_classes', $classData, ['id' => $classId])) {
                    throw new RuntimeException('فشل تحديث class.');
                }
            } else {
                $classId = $crud->insertId('item_classes', $classData);
                if (!$classId) {
                    throw new RuntimeException('فشل إضافة class.');
                }
            }
            $submittedClassIds[] = (int)$classId;

            foreach (($class['parts'] ?? []) as $part) {
                $partData = [
                    'class_id' => $classId,
                    'qty' => max(1, (int)($part['qty'] ?? 1)),
                    'height' => clean_nullable_num($part['height'] ?? null),
                    'length' => clean_nullable_num($part['length'] ?? null),
                    'width' => clean_nullable_num($part['width'] ?? null),
                    'kg' => clean_nullable_num($part['kg'] ?? null),
                    'note' => clean_str($part['note'] ?? '') ?: null,
                ];
                
                // unitSumm
                if ($unitType == 'm3') {
                    $m3Sums += $part['height'] *$part['length'] *$part['width'] ;
                }else{ $kgSums += $part['kg']; }
                $unitType = '';
                // _____

                $partId = clean_int($part['id'] ?? null);
                if ($partId && in_array($partId, $existingPartIds, true)) {
                    if (!$crud->update('class_parts', $partData, ['id' => $partId])) {
                        throw new RuntimeException('فشل تحديث part.');
                    }
                } else {
                    $partId = $crud->insertId('class_parts', $partData);
                    if (!$partId) {
                        throw new RuntimeException('فشل إضافة part.');
                    }
                }
                $submittedPartIds[] = (int)$partId;
            }
        }
    }

    $deletePartIds = array_diff($existingPartIds, $submittedPartIds);
    foreach ($deletePartIds as $partId) {
        $crud->delete('class_parts', ['id' => $partId]);
    }

    $deleteClassIds = array_diff($existingClassIds, $submittedClassIds);
    foreach ($deleteClassIds as $classId) {
        delete_parts_by_class_id($pdo, $classId);
        $crud->delete('item_classes', ['id' => $classId]);
    }

    $deleteItemIds = array_diff($existingItemIds, $submittedItemIds);
    foreach ($deleteItemIds as $itemId) {
        delete_classes_by_item_id($pdo, $itemId);
        $crud->delete('cstm_items', ['id' => $itemId]);
    }

    $pdo->commit();
    echo json_encode([
        'success' => true,
        'message' => $id ? 'تم تحديث الفاتورة بنجاح.' : 'تم حفظ الفاتورة بنجاح.',
        'cstm_inv_id' => (int)$invoiceId,
        // 'redirect' => '../view_cstm_inv.php?id=' . (int)$invoiceId ,
        'redirect' => PAGES_URL.'/cstm_inv/inv_sel_price.php?id=' . (int)$invoiceId ,
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
