<?php 


// الاستخدام عند التسجيل
include "security.php";

$password = "123456";

$hash = hashPassword($password);

// تخزن $hash في قاعدة البيانات



//_____________________

// الاستخدام عند تسجيل الدخول

include "security.php";

$password = $_POST['password']; // كلمة المرور التي ادخلها المستخدم
$hash = $row['password']; // الكلمة المخزنة في قاعدة البيانات

if(verifyPassword($password, $hash)){
    echo "تم تسجيل الدخول";
}else{
    echo "كلمة المرور خاطئة";
}