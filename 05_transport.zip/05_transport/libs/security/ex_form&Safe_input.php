<?php
include "forms.php";

$name = sanitizeInput($_POST['name']);
$username = sanitizeInput($_POST['username']);
$email = sanitizeInput($_POST['email']);
$phone = sanitizeInput($_POST['phone']);
$password = $_POST['password'];

if (!isValidName($name)) {
    echo "الاسم غير صالح";
}

if (!isValidUsername($username)) {
    echo "اسم المستخدم غير صالح";
}

if (!isValidEmail($email)) {
    echo "البريد الإلكتروني غير صالح";
}

if (!isValidPhone($phone)) {
    echo "رقم الهاتف يجب أن يكون 8 أرقام";
}

if (!isStrongPassword($password)) {
    echo "كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل مع حرف كبير وحرف صغير ورقم";
}
?>