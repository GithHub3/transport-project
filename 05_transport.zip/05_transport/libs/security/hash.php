<?php

// تشفير كلمة المرور (Hash)
function hashPass($password){
    return password_hash($password, PASSWORD_DEFAULT);
}

// التحقق من كلمة المرور
function decPass($password, $hash){
    return password_verify($password, $hash);
}

?>