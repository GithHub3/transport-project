<?php

require_once __DIR__ . "/../../config.php";
require_once CRUD_PATH;

$checkCrud = new CRUD();


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


// إذا لم تكن الجلسة موجودة، تحقق من كوكي remember_me
if (!isset($_SESSION['user_id']) && isset($_COOKIE['remember_me'])) {
    $token = $_COOKIE['remember_me'];

    // البحث عن الرمز في قاعدة البيانات
    $stmt = $pdo->prepare("SELECT user_id, expires_at FROM user_tokens WHERE token = ?");
    $stmt->execute([$token]);
    $row = $stmt->fetch();

    if ($row) {
        // التحقق من أن الرمز لم ينتهِ صلاحيته
        if (strtotime($row['expires_at']) > time()) {
            // تسجيل الدخول التلقائي
            $_SESSION['user_id'] = $row['user_id'];

            // (اختياري) تجديد الرمز لتعزيز الأمان - إنشاء رمز جديد وحذف القديم
            $new_token = bin2hex(random_bytes(32));
            $new_expires = date('Y-m-d H:i:s', strtotime('+30 days'));

            // تحديث الجدول بالرمز الجديد
            $update = $pdo->prepare("UPDATE user_tokens SET token = ?, expires_at = ? WHERE token = ?");
            $update->execute([$new_token, $new_expires, $token]);

            // تحديث الكوكي بالرمز الجديد
            setcookie('remember_me', $new_token, strtotime('+30 days'), '/', '', true, true);
        } else {
            // الرمز منتهي الصلاحية: حذفه من قاعدة البيانات والكوكي
            $pdo->prepare("DELETE FROM user_tokens WHERE token = ?")->execute([$token]);
            setcookie('remember_me', '', time() - 3600, '/'); // حذف الكوكي
        }
    } else {
        // رمز غير موجود: حذف الكوكي
        setcookie('remember_me', '', time() - 3600, '/');
    }
}


if (empty($_SESSION['user_id']) || !isset($_SESSION['user_id'])) {
    header('Location: ' . PAGES_URL . '/login/login.php');
    exit;
}

$checkUserData = $checkCrud->selectOne('users','*',['id' => $_SESSION['user_id']]);
if ($checkUserData['sts'] != 'ok') {
    header('Location: ' . PAGES_URL . '/login/logout.php');
    exit;
}

function permCheck($p)
{
    $permCrud = new CRUD();
    $permData = $permCrud->selectOne('perms', '*', ['code' => $p]);
    $userPerms = $permCrud->areThere('user_perms', ['perm_id' => $permData['id'], 'user_id' => $_SESSION['user_id']]);
    return $userPerms;
}
