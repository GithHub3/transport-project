<?php

class FormSecurity
{
    /**
     * بدء الجلسة إذا لم تكن قد بدأت بعد
     */
    public static function startSession()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    // -------------------------------------------------------------------------
    // 1. CSRF Protection
    // -------------------------------------------------------------------------

    /**
     * توليد token CSRF وتخزينه في الجلسة
     * @return string
     */
    public static function generateCsrfToken()
    {
        self::startSession();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    /**
     * إرجاع حقل hidden يحتوي على token CSRF
     * @return string
     */
    public static function csrfField()
    {
        $token = self::generateCsrfToken();
        return '<input type="hidden" name="csrf_token" value="' . $token . '">';
    }

    /**
     * التحقق من صحة token CSRF المرسل
     * @param string $token
     * @return bool
     */
    public static function validateCsrfToken($token)
    {
        self::startSession();
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }

    /**
     * إزالة token CSRF بعد الاستخدام (اختياري)
     */
    public static function removeCsrfToken()
    {
        self::startSession();
        unset($_SESSION['csrf_token']);
    }

    // -------------------------------------------------------------------------
    // 2. Sanitization (للإخراج الآمن)
    // -------------------------------------------------------------------------

    /**
     * تنظيف أي نص لعرضه في HTML (منع XSS)
     * @param string $data
     * @return string
     */
    public static function escape($data)
    {
        return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    /**
     * تنظيف مصفوفة (مثل $_POST) لعرضها بشكل آمن
     * @param array $array
     * @return array
     */
    public static function escapeArray($array)
    {
        return array_map([self::class, 'escape'], $array);
    }

    // -------------------------------------------------------------------------
    // 3. Validation
    // -------------------------------------------------------------------------

    /**
     * التحقق من عنوان بريد إلكتروني صالح
     * @param string $email
     * @return bool
     */
    public static function validateEmail($email)
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    /**
     * التحقق من أن القيمة عدد صحيح
     * @param mixed $value
     * @return bool
     */
    public static function validateInt($value)
    {
        return filter_var($value, FILTER_VALIDATE_INT) !== false;
    }

    /**
     * التحقق من أن القيمة رقم (عدد عشري)
     * @param mixed $value
     * @return bool
     */
    public static function validateFloat($value)
    {
        return filter_var($value, FILTER_VALIDATE_FLOAT) !== false;
    }

    /**
     * التحقق من طول النص بين حدين
     * @param string $text
     * @param int $min
     * @param int $max
     * @return bool
     */
    public static function validateLength($text, $min, $max)
    {
        $len = mb_strlen($text, 'UTF-8');
        return $len >= $min && $len <= $max;
    }

    /**
     * التحقق من تاريخ بصيغة Y-m-d
     * @param string $date
     * @return bool
     */
    public static function validateDate($date)
    {
        $d = DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }

    // -------------------------------------------------------------------------
    // 4. Secure File Upload
    // -------------------------------------------------------------------------

    /**
     * رفع ملف بأمان
     * @param array $file عنصر من $_FILES (مثل $_FILES['avatar'])
     * @param string $targetDir المجلد المستهدف (يجب أن يكون موجوداً)
     * @param array $allowedTypes أنواع MIME المسموح بها (مثل ['image/jpeg', 'image/png'])
     * @param int $maxSize الحجم الأقصى بالبايت
     * @return array [success: bool, message: string, filePath: string|null]
     */
    public static function uploadFile($file, $targetDir, $allowedTypes, $maxSize)
    {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => 'خطأ في رفع الملف.', 'filePath' => null];
        }

        // التحقق من الحجم
        if ($file['size'] > $maxSize) {
            return ['success' => false, 'message' => 'حجم الملف أكبر من المسموح.', 'filePath' => null];
        }

        // التحقق من نوع MIME الفعلي
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if (!in_array($mime, $allowedTypes)) {
            return ['success' => false, 'message' => 'نوع الملف غير مسموح.', 'filePath' => null];
        }

        // توليد اسم آمن
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $newName = bin2hex(random_bytes(16)) . '.' . $extension;
        $targetPath = rtrim($targetDir, '/') . '/' . $newName;

        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            return ['success' => true, 'message' => 'تم رفع الملف بنجاح.', 'filePath' => $targetPath];
        } else {
            return ['success' => false, 'message' => 'فشل نقل الملف.', 'filePath' => null];
        }
    }

    // -------------------------------------------------------------------------
    // 5. Database Helper (PDO Prepared Statements)
    // -------------------------------------------------------------------------

    /**
     * تنفيذ استعلام PDO بأمان باستخدام prepared statements
     * @param PDO $pdo كائن الاتصال
     * @param string $sql الاستعلام (مع placeholders)
     * @param array $params البيانات المراد ربطها
     * @return PDOStatement|false
     */
    public static function safeQuery($pdo, $sql, $params = [])
    {
        $stmt = $pdo->prepare($sql);
        if ($stmt === false) {
            return false;
        }
        $stmt->execute($params);
        return $stmt;
    }
}




// حماية من المدخلات


/*

function cleanInput($data){
    $data = trim($data);                 // إزالة الفراغات
    $data = stripslashes($data);         // إزالة \
    $data = strip_tags($data);           // إزالة HTML
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8'); 
    return $data;
}
*/

function safeInput($data) {
    $data = trim($data);                                   // حذف الفراغات من البداية والنهاية
    $data = strip_tags($data);                             // حذف HTML و PHP tags
    $data = preg_replace('/[\r\n\t]+/', ' ', $data);       // تحويل الأسطر والتبويبات إلى فراغ
    $data = preg_replace('/\s+/', ' ', $data);             // توحيد الفراغات المتكررة
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');  // تحويل الرموز الخاصة
    return $data;
}

function isStrongPassword($password) {
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $password);
}

function isValidName($name) {
    return preg_match('/^[a-zA-Z\s]{2,50}$/', $name);
}

function isValidUsername($username) {
    return preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username);
}

function isValidPhone($phone) {
    return preg_match('/^[0-9]{8}$/', $phone);
}

function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

?>