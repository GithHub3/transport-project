<?php
require_once __DIR__."/../../config.php";
require_once CRUD_PATH;

$psql = new CRUD();



