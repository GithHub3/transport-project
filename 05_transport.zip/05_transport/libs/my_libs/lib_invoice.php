<?php
require_once __DIR__."/../../config.php";
require_once CRUD_PATH;

//_______________
//My  

function itemRow($itemId){
$summ = 0 ;
$psql = new CRUD();
$classes = $psql->select('item_classes' ,'*',['item_id']=> $itemId);
foreach($classes as $c){

$summ += $psql->count('class_parts' ,['class_id']=> $c['id']);

}
return $summ ;

}

function itemRow2($itemId){
$summ = 0 ;
$psql = new CRUD();
$classes = $psql->select('item_classes' ,'*',['item_id']=> $itemId);
foreach($classes as $c){

$summ += $psql->count('class_parts' ,['class_id']=> $c['id']);

}
return $summ ;

}

function classRow($classId){
$summ = 0 ;
$psql = new CRUD();

$summ += $psql->count('class_parts' ,['class_id']=> $classId);


return $summ ;

}


//________________

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function clean_str($value) {
    return trim((string)$value);
}

function clean_num($value) {
    return $value === '' || $value === null ? 0 : (float)$value;
}

function clean_nullable_num($value) {
    return $value === '' || $value === null ? null : (float)$value;
}

function clean_int($value) {
    return $value === '' || $value === null ? null : (int)$value;
}

function to_datetime_or_now($value) {
    $value = clean_str($value);
    return $value ? str_replace('T', ' ', $value) . ':00' : date('Y-m-d H:i:s');
}

function get_coins() {
    $crud = new CRUD();
    return $crud->select('coins', '*', [], 'name ASC') ?: [];
}

function get_invoice_full($id) {
    $pdo = db_conn();

    $stmt = $pdo->prepare("SELECT i.*, 
        s1.name_ar AS send_name_ar, s1.name_en AS send_name_en,
        s2.name_ar AS receive_name_ar, s2.name_en AS receive_name_en,
        stf.name_ar AS state_from_ar, stf.name_en AS state_from_en, stf.code AS state_from_code,
        stt.name_ar AS state_to_ar, stt.name_en AS state_to_en, stt.code AS state_to_code,
        co.name AS coin_name, co.code AS coin_code
        FROM cstm_inv i
        LEFT JOIN cstms s1 ON s1.id = i.cstm_id_send
        LEFT JOIN cstms s2 ON s2.id = i.cstm_id_receive
        LEFT JOIN states stf ON stf.id = i.state_id_from
        LEFT JOIN states stt ON stt.id = i.state_id_to
        LEFT JOIN coins co ON co.id = i.coin_id
        WHERE i.id = :id LIMIT 1");
    $stmt->execute(['id' => $id]);
    $invoice = $stmt->fetch();
    if (!$invoice) {
        return null;
    }

    $stmt = $pdo->prepare("SELECT * FROM cstm_items WHERE cstm_inv_id = :id ORDER BY id ASC");
    $stmt->execute(['id' => $id]);
    $items = $stmt->fetchAll() ?: [];

    foreach ($items as &$item) {
        $stmtClass = $pdo->prepare("SELECT * FROM item_classes WHERE item_id = :item_id ORDER BY id ASC");
        $stmtClass->execute(['item_id' => $item['id']]);
        $classes = $stmtClass->fetchAll() ?: [];

        foreach ($classes as &$class) {
            $stmtPart = $pdo->prepare("SELECT * FROM class_parts WHERE class_id = :class_id ORDER BY id ASC");
            $stmtPart->execute(['class_id' => $class['id']]);
            $class['parts'] = $stmtPart->fetchAll() ?: [];
        }

        $item['classes'] = $classes;
    }

    $invoice['items'] = $items;
    return $invoice;
}

function get_invoice_form_data($id) {
    $invoice = get_invoice_full($id);
    if (!$invoice) {
        return null;
    }

    $send = [];
    if (!empty($invoice['cstm_id_send'])) {
        $send = [
            'id' => $invoice['cstm_id_send'],
            'text' => trim(($invoice['send_name_ar'] ?: '') . ' | ' . ($invoice['send_name_en'] ?: ''), ' |'),
        ];
    }

    $receive = [];
    if (!empty($invoice['cstm_id_receive'])) {
        $receive = [
            'id' => $invoice['cstm_id_receive'],
            'text' => trim(($invoice['receive_name_ar'] ?: '') . ' | ' . ($invoice['receive_name_en'] ?: ''), ' |'),
        ];
    }

    $stateFrom = [];
    if (!empty($invoice['state_id_from'])) {
        $stateFrom = [
            'id' => $invoice['state_id_from'],
            'text' => trim(($invoice['state_from_ar'] ?: '') . ' | ' . ($invoice['state_from_en'] ?: '') . ' | ' . ($invoice['state_from_code'] ?: ''), ' |'),
        ];
    }

    $stateTo = [];
    if (!empty($invoice['state_id_to'])) {
        $stateTo = [
            'id' => $invoice['state_id_to'],
            'text' => trim(($invoice['state_to_ar'] ?: '') . ' | ' . ($invoice['state_to_en'] ?: '') . ' | ' . ($invoice['state_to_code'] ?: ''), ' |'),
        ];
    }

    return [
        'invoice' => $invoice,
        'selected_send' => $send,
        'selected_receive' => $receive,
        'selected_state_from' => $stateFrom,
        'selected_state_to' => $stateTo,
    ];
}

function delete_parts_by_class_id(PDO $pdo, $classId) {
    $stmt = $pdo->prepare("DELETE FROM class_parts WHERE class_id = :id");
    $stmt->execute(['id' => $classId]);
}

function delete_classes_by_item_id(PDO $pdo, $itemId) {
    $stmt = $pdo->prepare("SELECT id FROM item_classes WHERE item_id = :id");
    $stmt->execute(['id' => $itemId]);
    $classIds = $stmt->fetchAll(PDO::FETCH_COLUMN) ?: [];
    foreach ($classIds as $classId) {
        delete_parts_by_class_id($pdo, $classId);
    }
    $stmt = $pdo->prepare("DELETE FROM item_classes WHERE item_id = :id");
    $stmt->execute(['id' => $itemId]);
}

function delete_items_by_invoice_id(PDO $pdo, $invoiceId) {
    $stmt = $pdo->prepare("SELECT id FROM cstm_items WHERE cstm_inv_id = :id");
    $stmt->execute(['id' => $invoiceId]);
    $itemIds = $stmt->fetchAll(PDO::FETCH_COLUMN) ?: [];
    foreach ($itemIds as $itemId) {
        delete_classes_by_item_id($pdo, $itemId);
    }
    $stmt = $pdo->prepare("DELETE FROM cstm_items WHERE cstm_inv_id = :id");
    $stmt->execute(['id' => $invoiceId]);
}
