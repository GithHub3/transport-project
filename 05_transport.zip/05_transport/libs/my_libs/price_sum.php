<?php
require_once __DIR__ . "/../../config.php";
require_once CRUD_PATH;

$pcd = new CRUD();

$prKg = 0;
$prM3 = 0;
$allKg = 0;
// $maxPrice = 0;
// $minPrice = 0;

$pPrice = $pcd->selectOne('prices', '*');
$pItem = $pcd->select('cstm_items', '*', ['cstm_inv_id' => $id]);
foreach ($pItem as $pi) {

    $pClass = $pcd->select('item_classes', '*', ['item_id' => $pi['id']]);
    foreach ($pClass as $pcls) {

        $pPart = $pcd->select('class_parts', '*', ['class_id' => $pcls['id']]);
        foreach ($pPart as $pp) {
            $allKg += $pp['kg']*$pp['qty'];

            if ($pcls['unit'] == 'm3' ) {
                $prM3 += ($pp['height'] * $pp['length'] * $pp['width'])*$pp['qty'];
            }
            else {
                $prKg += $pp['kg']*$pp['qty'];
            }

        }
    }
}


$maxPrice = ($prM3 * $pPrice['max_price_m3']) + ($prKg * $pPrice['max_price_kg']);
$minPrice = ($prM3 * $pPrice['min_price_m3']) + ($prKg * $pPrice['min_price_kg']);


$minPrice = (int) $minPrice ;
$maxPrice = (int) $maxPrice ;


// $updAmount 
 /*
$pcd->update(
    'cstm_inv',
    ['amount' => $maxPrice],
    ['id' => $id]
);

*/