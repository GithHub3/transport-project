function loadFun(page_url, targetElementId, interval = 5000) {
    // التحقق من المدخلات
    if (!page_url || !targetElementId) {
        console.error('يجب تحديد url و targetElementId');
        return null;
    }

    // دالة الجلب والتحديث
    function fetchAndUpdate() {
        fetch(page_url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            })
            .then(html => {
                const targetElement = document.getElementById(targetElementId);
                if (targetElement) {
                    targetElement.innerHTML = html;
                } else {
                    console.warn(`العنصر ذو id "${targetElementId}" غير موجود`);
                }
            })
            .catch(error => {
                console.error('حدث خطأ في الجلب:', error);
            });
    }

    // تنفيذ الجلب فوراً
    fetchAndUpdate();

    // بدء التكرار
    const intervalId = setInterval(fetchAndUpdate, interval);

    // إرجاع دالة لإيقاف التكرار (اختياري)
    return {
        stop: () => clearInterval(intervalId),
        refresh: fetchAndUpdate // للتحديث اليدوي
    };
}