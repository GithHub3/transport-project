<?php 
require_once __DIR__ . '/../../../config.php';

 ?>

<script>

const form = document.getElementById('invoiceForm');
const alertBox = document.getElementById('alertBox');
const itemsContainer = document.getElementById('itemsContainer');
const addItemBtn = document.getElementById('addItemBtn');
const coins = Array.isArray(window.COINS) ? window.COINS : [];
const invoiceData = window.INVOICE_DATA || null;

function showAlert(message, type = 'success') {
    alertBox.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show rounded-4" role="alert">
            <div class="white-space-pre-line">${message}</div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = value ?? '';
    return div.innerHTML;
}

function createCoinOptions(selected = '') {
    let html = '<option value="">بدون</option>';
    coins.forEach(coin => {
        const isSelected = String(selected) === String(coin.id) ? 'selected' : '';
        html += `<option value="${coin.id}" ${isSelected}>${escapeHtml(coin.name)} (${escapeHtml(coin.code)})</option>`;
    });
    return html;
}

function initAjaxSelect($el, url, placeholder) {
    $el.select2({
        theme: 'bootstrap-5',
        dir: 'rtl',
        width: '100%',
        placeholder,
        allowClear: true,
        ajax: {
            url,
            dataType: 'json',
            delay: 250,
            data: params => ({ q: params.term || '', page: params.page || 1 }),
            processResults: data => data,
            cache: true
        },
        language: {
            inputTooShort: () => 'اكتب للبحث',
            noResults: () => 'لا توجد نتائج'
        },
        minimumInputLength: 1
    });
}

function initCustomerSelect(select) {
    const $select = $(select);
    initAjaxSelect($select, '<?php echo BASE_URL ; ?>/libs/ajax/search_cstms.php', 'ابحث عن عميل');
    const newBox = document.querySelector(select.dataset.newBox);
    const statusId = select.id === 'send_customer_select' ? 'send_customer_status' : 'receive_customer_status';
    const status = document.getElementById(statusId);

    $select.on('select2:clear', () => {
        newBox.classList.remove('d-none');
        status.textContent = 'الاسم غير موجود. أدخل بيانات عميل جديد.';
        status.className = 'form-text text-danger mt-1';
    });

    $select.on('select2:select', () => {
        newBox.classList.add('d-none');
        status.textContent = 'تم اختيار عميل موجود.';
        status.className = 'form-text text-success mt-1';
    });

    if (!$select.val()) {
        newBox.classList.remove('d-none');
    }
}

function initStateSelect(select, placeholder = 'ابحث باسم الولاية أو الكود') {
    const $select = $(select);
    initAjaxSelect($select, '<?php echo BASE_URL ; ?>/libs/ajax/search_states.php', placeholder);
    $select.on('select2:clear', () => validateStateSelect(select));
    $select.on('select2:select', () => validateStateSelect(select));
}

function validateStateSelect(select) {
    const messageBox = select.closest('.col-md-6, .col-md-12, .col-lg-6')?.querySelector('.invalid-state-message');
    if (!messageBox) return true;
    if (!select.value) {
        messageBox.textContent = 'لا توجد ولاية بهذا الاسم.';
        return false;
    }
    messageBox.textContent = '';
    return true;
}

async function deleteExistingNode(type, id) {
    const formData = new FormData();
    formData.append('type', type);
    formData.append('id', id);
    const res = await fetch('<?php echo BASE_URL ; ?>/libs/ajax/delete_node.php', { method: 'POST', body: formData });
    return res.json();
}

function buildPartElement(data = {}) {
    const part = document.getElementById('partTemplate').content.firstElementChild.cloneNode(true);
    if (data.id) part.dataset.id = data.id;
    part.querySelector('.part-qty').value = data.qty ?? 1;
    part.querySelector('.part-height').value = data.height ?? '';
    part.querySelector('.part-length').value = data.length ?? '';
    part.querySelector('.part-width').value = data.width ?? '';
    part.querySelector('.part-kg').value = data.kg ?? '';
    part.querySelector('.part-note').value = data.note ?? '';

    part.querySelector('.remove-part-btn').addEventListener('click', async () => {
        const id = part.dataset.id;
        if (id) {
            if (!confirm('حذف هذا part من قاعدة البيانات؟')) return;
            const data = await deleteExistingNode('part', id);
            if (!data.success) {
                showAlert(data.message || 'فشل حذف part.', 'danger');
                return;
            }
        }
        part.remove();
    });
    return part;
}

function buildClassElement(data = {}) {
    const classEl = document.getElementById('classTemplate').content.firstElementChild.cloneNode(true);
    if (data.id) classEl.dataset.id = data.id;
    classEl.querySelector('.class-name-ar').value = data.name_ar ?? '';
    classEl.querySelector('.class-name-en').value = data.name_en ?? '';
    classEl.querySelector('.class-unit').value = data.unit ?? 'm3';
    classEl.querySelector('.class-note').value = data.note ?? '';

    const partsContainer = classEl.querySelector('.parts-container');
    classEl.querySelector('.add-part-btn').addEventListener('click', () => partsContainer.appendChild(buildPartElement()));
    classEl.querySelector('.remove-class-btn').addEventListener('click', async () => {
        const id = classEl.dataset.id;
        if (id) {
            if (!confirm('حذف هذا class وكل أجزائه؟')) return;
            const data = await deleteExistingNode('class', id);
            if (!data.success) {
                showAlert(data.message || 'فشل حذف class.', 'danger');
                return;
            }
        }
        classEl.remove();
    });

    const parts = Array.isArray(data.parts) && data.parts.length ? data.parts : [{}];
    parts.forEach(part => partsContainer.appendChild(buildPartElement(part)));
    return classEl;
}

function buildItemElement(data = {}) {
    const itemEl = document.getElementById('itemTemplate').content.firstElementChild.cloneNode(true);
    if (data.id) itemEl.dataset.id = data.id;
    itemEl.querySelector('.item-coin-id').innerHTML = createCoinOptions(data.coin_id ?? '');
    itemEl.querySelector('.item-inv-num').value = data.inv_num ?? '';
    itemEl.querySelector('.item-name-ar').value = data.name_ar ?? '';
    itemEl.querySelector('.item-name-en').value = data.name_en ?? '';
    itemEl.querySelector('.item-dt').value = data.dt ? String(data.dt).replace(' ', 'T').slice(0, 16) : new Date().toISOString().slice(0, 16);
    itemEl.querySelector('.item-amount').value = data.amount ?? 0;
    itemEl.querySelector('.item-paid').value = data.paid ?? 0;
    itemEl.querySelector('.item-note').value = data.note ?? '';

    const classesContainer = itemEl.querySelector('.classes-container');
    itemEl.querySelector('.add-class-btn').addEventListener('click', () => classesContainer.appendChild(buildClassElement()));
    itemEl.querySelector('.remove-item-btn').addEventListener('click', async () => {
        const id = itemEl.dataset.id;
        if (id) {
            if (!confirm('حذف هذا العنصر مع كل الأصناف والأجزاء؟')) return;
            const data = await deleteExistingNode('item', id);
            if (!data.success) {
                showAlert(data.message || 'فشل حذف العنصر.', 'danger');
                return;
            }
        }
        itemEl.remove();
    });

    const classes = Array.isArray(data.classes) && data.classes.length ? data.classes : [{}];
    classes.forEach(cls => classesContainer.appendChild(buildClassElement(cls)));
    return itemEl;
}

function collectNestedData() {
    return Array.from(itemsContainer.querySelectorAll('.item-card')).map(itemEl => ({
        id: itemEl.dataset.id || '',
        inv_num: itemEl.querySelector('.item-inv-num').value.trim(),
        coin_id: itemEl.querySelector('.item-coin-id').value,
        name_ar: itemEl.querySelector('.item-name-ar').value.trim(),
        name_en: itemEl.querySelector('.item-name-en').value.trim(),
        dt: itemEl.querySelector('.item-dt').value,
        amount: itemEl.querySelector('.item-amount').value,
        paid: itemEl.querySelector('.item-paid').value,
        note: itemEl.querySelector('.item-note').value.trim(),
        classes: Array.from(itemEl.querySelectorAll('.class-card')).map(classEl => ({
            id: classEl.dataset.id || '',
            name_ar: classEl.querySelector('.class-name-ar').value.trim(),
            name_en: classEl.querySelector('.class-name-en').value.trim(),
            unit: classEl.querySelector('.class-unit').value,
            note: classEl.querySelector('.class-note').value.trim(),
            parts: Array.from(classEl.querySelectorAll('.part-row')).map(partEl => ({
                id: partEl.dataset.id || '',
                qty: partEl.querySelector('.part-qty').value,
                height: partEl.querySelector('.part-height').value,
                length: partEl.querySelector('.part-length').value,
                width: partEl.querySelector('.part-width').value,
                kg: partEl.querySelector('.part-kg').value,
                note: partEl.querySelector('.part-note').value.trim(),
            }))
        }))
    }));
}

function validateForm() {
    let ok = true;
    document.querySelectorAll('.required-state').forEach(select => {
        if (!validateStateSelect(select)) ok = false;
    });
    if (!itemsContainer.querySelector('.item-card')) {
        showAlert('أضف عنصراً واحداً على الأقل.', 'danger');
        ok = false;
    }
    return ok;
}

async function submitForm(e) {
    e.preventDefault();
    if (!validateForm()) return;

    const saveBtn = document.getElementById('saveBtn');
    saveBtn.disabled = true;
    const oldText = saveBtn.textContent;
    saveBtn.textContent = 'جاري الحفظ...';

    try {
        const formData = new FormData(form);
        formData.append('nested_data', JSON.stringify(collectNestedData()));

        const res = await fetch('ajax/save_cstm_inv.php', {
            method: 'POST',
            body: formData,
        });
        const data = await res.json();

        if (!data.success) {
            showAlert(data.message || 'فشل الحفظ.', 'danger');
            return;
        }

        showAlert(`${data.message}<br><a href="<?php echo PAGES_URL ; ?>/cstm_inv/view_cstm_inv.php?id=${data.cstm_inv_id}" class="alert-link">فتح الفاتورة الآن</a>`, 'success');
        setTimeout(() => {
            window.location.href = `view_cstm_inv.php?id=${data.cstm_inv_id}`;
        }, 900);
    } catch (err) {
        showAlert('حدث خطأ أثناء الحفظ.', 'danger');
    } finally {
        saveBtn.disabled = false;
        saveBtn.textContent = oldText;
    }
}

function bootExistingData() {
    if (invoiceData && Array.isArray(invoiceData.items) && invoiceData.items.length) {
        invoiceData.items.forEach(item => itemsContainer.appendChild(buildItemElement(item)));
    } else {
        itemsContainer.appendChild(buildItemElement());
    }
}

$(function () {
    document.querySelectorAll('.customer-select').forEach(initCustomerSelect);
    document.querySelectorAll('.state-select').forEach(select => initStateSelect(select, select.dataset.placeholder || 'ابحث عن ولاية'));
    addItemBtn.addEventListener('click', () => itemsContainer.appendChild(buildItemElement()));
    form.addEventListener('submit', submitForm);
    bootExistingData();
});

</script>
