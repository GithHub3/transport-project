// Shared Form Utilities

class FormUtils {

    static validateUsername(value) {
        if (!value || value.trim() === '') {
            return { isValid: false, message: 'اسم المستخدم مطلوب' };
        }
        return { isValid: true };
    }

    static validatePassword(value) {
        if (!value) {
            return { isValid: false, message: 'Password is required' };
        }
        if (value.length < 8) {
            return { isValid: false, message: 'Password must be at least 8 characters long' };
        }
        if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(value)) {
            return { isValid: false, message: 'Password must contain uppercase, lowercase, and number' };
        }
        return { isValid: true };
    }

    static showError(fieldName, message) {
        const formGroup = document.getElementById(fieldName).closest('.form-group');
        const errorElement = document.getElementById(fieldName + 'Error');

        if (formGroup && errorElement) {
            formGroup.classList.add('error');
            errorElement.textContent = message;
            errorElement.classList.add('show');
        }
    }

    static clearError(fieldName) {
        const formGroup = document.getElementById(fieldName).closest('.form-group');
        const errorElement = document.getElementById(fieldName + 'Error');

        if (formGroup && errorElement) {
            formGroup.classList.remove('error');
            errorElement.classList.remove('show');
            errorElement.textContent = '';
        }
    }

    static showSuccess(fieldName) {
        const field = document.getElementById(fieldName);
        const wrapper = field?.closest('.input-wrapper');

        if (wrapper) {
            wrapper.style.borderColor = '#22c55e';
            setTimeout(() => {
                wrapper.style.borderColor = '';
            }, 2000);
        }
    }

    static showNotification(message, type = 'info', container = null) {
        const targetContainer = container || document.querySelector('form');
        if (!targetContainer) return;

        const notification = document.createElement('div');
        notification.className = `notification ${type}`;

        notification.innerHTML = `
            <div style="
                background: rgba(6,182,212,0.1);
                border:1px solid rgba(6,182,212,0.3);
                border-radius:12px;
                padding:12px;
                margin-top:16px;
                text-align:center;
                font-size:14px;">
                ${message}
            </div>
        `;

        targetContainer.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

}