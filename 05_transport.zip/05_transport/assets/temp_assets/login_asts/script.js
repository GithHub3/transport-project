// Login Form JavaScript

class LoginForm1 {

    constructor() {

        this.form = document.getElementById('loginForm');
        this.submitBtn = this.form.querySelector('.login-btn');
        this.passwordToggle = document.getElementById('passwordToggle');
        this.passwordInput = document.getElementById('password');
        this.isSubmitting = false;

        this.validators = {
            username: FormUtils.validateUsername,
            password: FormUtils.validatePassword
        };

        this.init();
    }

    init() {
        this.addEventListeners();
    }

    addEventListeners() {

        this.form.addEventListener('submit', (e) => this.handleSubmit(e));

        Object.keys(this.validators).forEach(fieldName => {

            const field = document.getElementById(fieldName);

            if (field) {

                field.addEventListener('blur', () => this.validateField(fieldName));

                field.addEventListener('input', () => {
                    FormUtils.clearError(fieldName);
                });

            }

        });

    }

    handleSubmit(e) {

        e.preventDefault();

        if (this.isSubmitting) return;

        const isValid = this.validateForm();

        if (isValid) {

            this.isSubmitting = true;

            this.submitBtn.disabled = true;

            this.form.submit();

        } else {

            this.shakeForm();

        }

    }

    validateForm() {

        let isValid = true;

        Object.keys(this.validators).forEach(fieldName => {

            if (!this.validateField(fieldName)) {
                isValid = false;
            }

        });

        return isValid;

    }

    validateField(fieldName) {

        const field = document.getElementById(fieldName);
        const validator = this.validators[fieldName];

        if (!field || !validator) return true;

        const result = validator(field.value.trim());

        if (result.isValid) {

            FormUtils.clearError(fieldName);
            FormUtils.showSuccess(fieldName);

        } else {

            FormUtils.showError(fieldName, result.message);

        }

        return result.isValid;

    }

    shakeForm() {

        this.form.style.animation = 'shake 0.5s';

        setTimeout(() => {
            this.form.style.animation = '';
        }, 500);

    }

}

document.addEventListener('DOMContentLoaded', () => {

    new LoginForm1();

});