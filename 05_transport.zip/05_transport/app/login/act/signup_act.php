<?php 


require_once __DIR__ . "/../../../config.php";
require_once SEC_PATH. "/forms.php";
require_once CRUD_PATH;

$crud = new CRUD();


//قيد التعديل


// التحقق من CSRF
if (!FormSecurity::validateCsrfToken($_POST['csrf_token'])) {
    die('طلب غير مصرح به (CSRF)');
}

// (اختياري) إزالة token بعد الاستخدام لمنع إعادة الاستخدام
FormSecurity::removeCsrfToken();

// التحقق من صحة البيانات
$errors = [];

if (empty($_POST['username'])) {
    $errors[] = 'الإسم مطلوب.';
} elseif (!FormSecurity::validateLength($_POST['username'], 3, 50)) {
    $errors[] = 'الإسم يجب أن يكون بين 3 و50 حرفاً.';
}elseif ($crud->count('cstms', ['fullname' => $_POST['email']]) > 0 ) {
    $errors[] = 'هذا الإسم غير متاح !!.';
}

if (empty($_POST['email'])) {
    $errors[] = 'البريد الإلكتروني مطلوب.';
} elseif ($crud->count('cstms', ['email' => $_POST['email']]) > 0 ) {
    $errors[] = 'البريد الإلكتروني  مسجل بالفعل!!.';
}

// إذا لا توجد أخطاء، قم بمعالجة البيانات (مثلاً الإدخال في قاعدة البيانات)
if (empty($errors)) {

    $pdo = new PDO('mysql:host=localhost;dbname=test', 'user', 'pass');
    $sql = "INSERT INTO users (username, email) VALUES (:username, :email)";
    $params = [
        'username' => $_POST['username'],  // لا نحتاج لتنقية إضافية لأن PDO يتولى ذلك
        'email'    => $_POST['email']
    ];
    $result = FormSecurity::safeQuery($pdo, $sql, $params);
    if ($result) {
        echo "تم الإدراج بنجاح.";
    } else {
        echo "حدث خطأ في قاعدة البيانات.";
    }
} else {
    // عرض الأخطاء
    foreach ($errors as $error) {
        echo '<p style="color:red">' . FormSecurity::escape($error) . '</p>';
    }
}

exit;