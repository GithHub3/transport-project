<?php


require_once __DIR__ . "/../../../config.php";
require_once SEC_PATH . "/forms.php";
require_once SEC_PATH . "/hash.php";
require_once CRUD_PATH;

$crud = new CRUD();

$all_errors = " ";

//قيد التعديل


// التحقق من CSRF
if (!FormSecurity::validateCsrfToken($_POST['csrf_token'])) {
    die('طلب غير مصرح به (CSRF)');
}

// (اختياري) إزالة token بعد الاستخدام لمنع إعادة الاستخدام
FormSecurity::removeCsrfToken();

// التحقق من صحة البيانات
$errors = [];



if (empty($_POST['username'])) {
    $errors[] = 'إسم المستخدم مطلوب.';
}


if (empty($_POST['password'])) {
    $errors[] = ' كلمة المرور مطلربة!!.';
}



$username = safeInput($_POST['username']);

$pass = $_POST['password'];


if (!isStrongPassword($password)) {
     $errors[] = "كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل مع حرف كبير وحرف صغير ورقم";
}





// إذا لا توجد أخطاء، قم بمعالجة البيانات (مثلاً الإدخال في قاعدة البيانات)
if (empty($errors)) {

    $result = $crud->selectOne('users', '*', ['username' => $username ]);




    if (empty($result)) {
        echo '<script>
    alert(" كلمة المرور او البريد الالكتروني خطأ !! ");
    window.location.href = "../login.php"; 
</script>
';
        exit;
    } else {

if(decPass($pass,$result['pass'])){
        $user_data = $result[0];

        if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

        $_SESSION['user_id'] = $user_data['id'];
        $cstm_id = $user_data['id'];

        // إذا تم تحديد "تذكرني"
        if (isset($_POST['remember']) && $_POST['remember'] == '1') {
            // إنشاء رمز عشوائي بطول 64 حرفًا (مثلاً)
            $token = bin2hex(random_bytes(32)); // 64 حرفًا hex

            // مدة الصلاحية (مثلاً 30 يومًا)
            $expires = date('Y-m-d H:i:s', strtotime('+30 days'));

            // تخزين الرمز في قاعدة البيانات
            // $stmt = $pdo->prepare("INSERT INTO cstm_tokens (cstm_id, token, expires_at) VALUES (?, ?, ?)");
            // $stmt->execute([$cstm_id, $token, $expires]);
            $crud->insert('user_tokens',[
    'user_id' => $cstm_id,
    'token' => $token,
    'expires_at' => $expires
]);

            // وضع الكوكي في المتصفح (آمن، HttpOnly، SameSite)
            setcookie(
                'remember_me',           // اسم الكوكي
                $token,                  // القيمة
                strtotime('+30 days'),    // انتهاء الصلاحية (ثواني)
                '/',                      // المسار
                '',                       // المجال (اختياري)
                true,                     // Secure (لـ HTTPS)
                true                      // HttpOnly
            );
        }

        // توجيه المستخدم إلى الصفحة الرئيسية
        header('Location: ' . PAGES_URL . '/index.php');
        exit;
    }else{ 

echo '<script>
    alert(" كلمة المرور او البريد الالكتروني خطأ !! ");
    window.location.href = "../login.php"; 
</script>
';
        exit;
}

}
} else {
    // عرض الأخطاء
    foreach ($errors as $error) {
        echo '<p style="color:red">' . FormSecurity::escape($error) . '</p>';

        // $all_errors .= FormSecurity::escape($error) . " \n ";
    }
    //     echo '<script>
    //     alert(" ' . $all_errors . '  ");
    // window.location.href = "../login.php"; 
    // </script>
    //   ';
    exit;
}

exit;
