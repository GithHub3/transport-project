<?php
// $imgsSrc="./../includes/images";

require_once __DIR__ . "/../../config.php";
require_once SEC_PATH. "/forms.php";


?>

<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول</title>
    <link rel="stylesheet" href="<?= TEMP_ASTS ?>/login_asts/style.css">
</head>

<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <h4>
                    اهلا بك في
                    <span class="bstah">
                        بسطة
                    </span>
                </h4>
                <p>تسجيل الدخول  </p>
            </div>

            <form class="login-form" id="loginForm" novalidate method="post" action="act/login_act.php">

                <?= FormSecurity::csrfField() ?>

                <div class="form-group">
                    <div class="input-wrapper">
<input type="text" id="username" name="username">
                        <label for="username">  اسم المستخدم</label>
                        <span class="focus-border"></span>
                    </div>
                    <span class="error-message" id="usernameError"></span>
                </div>

                <div class="form-group">
                    <div class="input-wrapper password-wrapper">
                        <input type="password" id="password" name="password" required autocomplete="current-password">
                        <label for="password">كلمة المرور</label>
                        <button type="button" class="password-toggle" id="passwordToggle" aria-label="Toggle password visibility">
                            <span class="eye-icon"></span>
                        </button>
                        <span class="focus-border"></span>
                    </div>
                    <span class="error-message" id="passwordError"></span>
                </div>

                <div class="form-options">
                    <label class="remember-wrapper">
                        <input type="checkbox" id="remember" name="remember">
                        <span class="checkbox-label">
                            <span class="checkmark"></span>
                            تذكرني
                        </span>
                    </label>
                    <a href="#" class="forgot-password">هل نسيت كلمة المرور؟</a>
                </div>

                <button type="submit" class="login-btn btn">
                    <span class="btn-text"> تسجيل الدخول</span>
                    <span class="btn-loader"></span>
                </button>
            </form>

            <div class="divider">
                <span>  </span>
            </div>



            <!-- <div class="signup-link">
                <p>Don't have an account? <a href="#">Sign up</a></p>
            </div> -->

            <!-- <div class="success-message" id="successMessage">
                <div class="success-icon">✓</div>
                <h3>Login Successful!</h3>
                <p>Redirecting to your dashboard...</p>
            </div> -->
        </div>
    </div>

    <script src="<?= TEMP_ASTS ?>/login_asts/form-utils.js"></script>
    <script src="<?= TEMP_ASTS ?>/login_asts/script.js"></script>
</body>

</html>