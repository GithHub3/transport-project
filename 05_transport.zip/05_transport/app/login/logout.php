<?php
// في صفحة logout.php
session_start();

if (isset($_SESSION['user_id']) && isset($_COOKIE['remember_me'])) {
    $token = $_COOKIE['remember_me'];
    // حذف الرمز من قاعدة البيانات
    $pdo->prepare("DELETE FROM user_tokens WHERE token = ?")->execute([$token]);
}

// إزالة الكوكي
setcookie('remember_me', '', time() - 3600, '/');

// تدمير الجلسة
session_destroy();
header('Location: login.php');
exit;