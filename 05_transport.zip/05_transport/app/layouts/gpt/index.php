<?php 
require_once __DIR__."/../../../config.php";
?>
<!-- http://localhost:8083/00_my_projects/05_transport/app/layouts/gpt/index.php -->
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Header & Navbar & Footer</title>

  <!-- Bootstrap CSS -->
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css"
    rel="stylesheet"
  />

  <!-- Bootstrap Icons -->
  <link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
  />

  <link rel="stylesheet" href="<?= MY_CSS ?>/gpt_head.css" />
</head>
<body>

  <!-- Header -->
  <header class="top-header py-2">
    <div class="container">
      <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
        <div class="header-info d-flex flex-wrap gap-3 align-items-center">
          <span><i class="bi bi-envelope-fill"></i> info@example.com</span>
          <span><i class="bi bi-telephone-fill"></i> +967 700 000 000</span>
        </div>
        <div class="header-social d-flex gap-3">
          <a href="#"><i class="bi bi-facebook"></i></a>
          <a href="#"><i class="bi bi-instagram"></i></a>
          <a href="#"><i class="bi bi-twitter-x"></i></a>
          <a href="#"><i class="bi bi-youtube"></i></a>
        </div>
      </div>
    </div>
  </header>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg custom-navbar sticky-top">
    <div class="container">
      <a class="navbar-brand fw-bold" href="#">
        <i class="bi bi-gem"></i> موقعي
      </a>

      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#mainNavbar"
        aria-controls="mainNavbar"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon custom-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="mainNavbar">
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0 align-items-lg-center">
          <li class="nav-item">
            <a class="nav-link active" href="#">الرئيسية</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">من نحن</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">الخدمات</a>
          </li>

          <!-- Dropdown -->
          <li class="nav-item dropdown">
            <a
              class="nav-link dropdown-toggle"
              href="#"
              id="pagesDropdown"
              role="button"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              الصفحات
            </a>
            <ul class="dropdown-menu text-end" aria-labelledby="pagesDropdown">
              <li><a class="dropdown-item" href="#">الأسئلة الشائعة</a></li>
              <li><a class="dropdown-item" href="#">المدونة</a></li>
              <li><a class="dropdown-item" href="#">الأسعار</a></li>
            </ul>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="#">الأعمال</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">تواصل معنا</a>
          </li>
        </ul>

        <div class="d-flex gap-2">
          <a href="#" class="btn btn-outline-light btn-sm px-3">دخول</a>
          <a href="#" class="btn btn-warning btn-sm px-3 fw-bold">ابدأ الآن</a>
        </div>
      </div>
    </div>
  </nav>

  <!-- Hero -->
  <section class="hero-section d-flex align-items-center">
    <div class="container text-center">
      <h1 class="fw-bold mb-3">تصميم متناسق مع الجوال والكمبيوتر</h1>
      <p class="lead mb-4">
        واجهة حديثة ونظيفة مع شريط تنقل احترافي وهيدر وفوتر أنيق.
      </p>
      <a href="#" class="btn btn-main btn-lg px-4">اكتشف المزيد</a>
    </div>
  </section>

  <!-- Content -->
  <main class="py-5">
    <div class="container">
      <div class="row g-4">
        <div class="col-md-4">
          <div class="info-card h-100">
            <i class="bi bi-phone"></i>
            <h4>متجاوب</h4>
            <p>يظهر بشكل ممتاز على الجوال والأجهزة اللوحية والشاشات الكبيرة.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="info-card h-100">
            <i class="bi bi-palette"></i>
            <h4>تصميم أنيق</h4>
            <p>ألوان متناسقة ومساحات مريحة مع مظهر حديث ومرتب.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="info-card h-100">
            <i class="bi bi-code-slash"></i>
            <h4>سهل التعديل</h4>
            <p>تستطيع تغيير النصوص والألوان والروابط بسهولة حسب مشروعك.</p>
          </div>
        </div>
      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer class="main-footer pt-5 pb-3">
    <div class="container">
      <div class="row g-4">
        <div class="col-md-4">
          <h5>عن الموقع</h5>
          <p>
            هذا مثال لفوتر احترافي مع روابط ومعلومات تواصل وتصميم متناسق مع جميع الأجهزة.
          </p>
        </div>

        <div class="col-md-4">
          <h5>روابط سريعة</h5>
          <ul class="footer-links list-unstyled">
            <li><a href="#">الرئيسية</a></li>
            <li><a href="#">الخدمات</a></li>
            <li><a href="#">الأعمال</a></li>
            <li><a href="#">تواصل معنا</a></li>
          </ul>
        </div>

        <div class="col-md-4">
          <h5>تواصل</h5>
          <ul class="footer-contact list-unstyled">
            <li><i class="bi bi-geo-alt-fill"></i> اليمن</li>
            <li><i class="bi bi-envelope-fill"></i> info@example.com</li>
            <li><i class="bi bi-telephone-fill"></i> +967 700 000 000</li>
          </ul>
        </div>
      </div>

      <hr class="footer-line" />

      <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
        <p class="mb-0">© 2026 جميع الحقوق محفوظة</p>
        <div class="footer-social d-flex gap-3">
          <a href="#"><i class="bi bi-facebook"></i></a>
          <a href="#"><i class="bi bi-instagram"></i></a>
          <a href="#"><i class="bi bi-twitter-x"></i></a>
          <a href="#"><i class="bi bi-youtube"></i></a>
        </div>
      </div>
    </div>
  </footer>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?= MY_JS ?>/gpt_head.js"></script>
</body>
</html>