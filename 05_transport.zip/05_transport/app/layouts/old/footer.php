<?php 

// echo "<br>".TEMP_CSS."<br>".TEMP_JS."<br>".TEMP_IMGS."<br>".TEMP_ASTS;
  require_once __DIR__."/../../config.php";
?>


<!-- 
  - FOOTER مبسط
-->
<footer>
  <div class="footer-nav">
    <div class="container">
      <ul class="footer-nav-list">
        <li class="footer-nav-item"><h2 class="nav-title">روابط سريعة</h2></li>
        <li class="footer-nav-item"><a href="#" class="footer-nav-link">الرئيسية</a></li>
        <li class="footer-nav-item"><a href="#" class="footer-nav-link">منتجات</a></li>
        <li class="footer-nav-item"><a href="#" class="footer-nav-link">اتصل بنا</a></li>
        <li class="footer-nav-item"><a href="#" class="footer-nav-link">عن المتجر</a></li>
      </ul>
      <ul class="footer-nav-list">
        <li class="footer-nav-item"><h2 class="nav-title">معلومات</h2></li>
        <li class="footer-nav-item"><a href="#" class="footer-nav-link">الشحن والتوصيل</a></li>
        <li class="footer-nav-item"><a href="#" class="footer-nav-link">سياسة الخصوصية</a></li>
        <li class="footer-nav-item"><a href="#" class="footer-nav-link">الشروط والأحكام</a></li>
      </ul>
      <ul class="footer-nav-list">
        <li class="footer-nav-item"><h2 class="nav-title">تابعنا</h2></li>
        <li class="footer-nav-item flex">
          <a href="#" class="footer-nav-link"><ion-icon name="logo-facebook"></ion-icon></a>
          <a href="#" class="footer-nav-link"><ion-icon name="logo-instagram"></ion-icon></a>
          <a href="#" class="footer-nav-link"><ion-icon name="logo-twitter"></ion-icon></a>
        </li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="container">
      <p class="copyright">جميع الحقوق محفوظة &copy; 2025 <a href="#">Anon</a></p>
    </div>
  </div>
</footer>

<!-- أيقونات Ionicon -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<!-- ملف الجافاسكريبت الأصلي (قد تحتاجه للقوائم المنسدلة الخفيفة) -->
<script src="<?= TEMP_JS ?>/script.js"></script>

<?php if (isset($extraJs)): ?>
        <?php foreach ($extraJs as $jsFile): ?>
            <script src="<?php echo MY_JS."/". $jsFile; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>

</body>
</html>