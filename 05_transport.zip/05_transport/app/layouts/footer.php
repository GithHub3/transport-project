<?php 

// echo "<br>".TEMP_CSS."<br>".TEMP_JS."<br>".TEMP_IMGS."<br>".TEMP_ASTS;
  require_once __DIR__."/../../../config.php";
?>


  <!-- Footer -->
  <footer class="main-footer pt-5 pb-3">
    <div class="container">
      <div class="row g-4">
        <div class="col-md-4">
          <h5>عن الموقع</h5>
          <p>
            هذا مثال لفوتر احترافي مع روابط ومعلومات تواصل وتصميم متناسق مع جميع الأجهزة.
          </p>
        </div>

        <div class="col-md-4">
          <h5>روابط سريعة</h5>
          <ul class="footer-links list-unstyled">
            <li><a href="#">الرئيسية</a></li>
            <li><a href="#">الخدمات</a></li>
            <li><a href="#">الأعمال</a></li>
            <li><a href="#">تواصل معنا</a></li>
          </ul>
        </div>

        <div class="col-md-4">
          <h5>تواصل</h5>
          <ul class="footer-contact list-unstyled">
            <li><i class="bi bi-geo-alt-fill"></i> اليمن</li>
            <li><i class="bi bi-envelope-fill"></i> info@example.com</li>
            <li><i class="bi bi-telephone-fill"></i> +967 700 000 000</li>
          </ul>
        </div>
      </div>

      <hr class="footer-line" />

      <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
        <p class="mb-0">© 2026 جميع الحقوق محفوظة</p>
        <div class="footer-social d-flex gap-3">
          <a href="#"><i class="bi bi-facebook"></i></a>
          <a href="#"><i class="bi bi-instagram"></i></a>
          <a href="#"><i class="bi bi-twitter-x"></i></a>
          <a href="#"><i class="bi bi-youtube"></i></a>
        </div>
      </div>
    </div>
  </footer>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?= MY_JS ?>/gpt_head.js"></script>
  <?php if (isset($extraJs)): ?>
        <?php foreach ($extraJs as $jsFile): ?>
            <script src="<?php echo MY_JS."/". $jsFile; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>