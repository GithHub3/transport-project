<?php 
// $imgsSrc="./../includes/images";

  require_once __DIR__."/../../config.php";
  require_once SEC_PATH."/check_user.php";
?>

<?php 
  include_once LYT_PATH."/header.php";
?>




<main>
     <br><br><br>
     <br><br><br>
     <br><br><br>
     <br><br><br>
     <br><br><br>
     <br><br><br>
     <br><br><br>
     <br><br><br>
     <br><br><br>
     <br><br><br>
     <br><br><br>
</main>






<?php 
  include_once LYT_PATH."/footer.php";
?>

