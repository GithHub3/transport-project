<?php
require_once __DIR__ . '/../../../config.php';
require_once MY_LIBS . '/lib_invoice.php';
$coins = get_coins();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$formData = $id ? get_invoice_form_data($id) : null;
if ($id && !$formData) {
    http_response_code(404);
    echo 'الفاتورة غير موجودة';
    exit;
}
$invoice = $formData['invoice'] ?? null;
$selectedSend = $formData['selected_send'] ?? [];
$selectedReceive = $formData['selected_receive'] ?? [];
$selectedStateFrom = $formData['selected_state_from'] ?? [];
$selectedStateTo = $formData['selected_state_to'] ?? [];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $id ? 'تعديل' : 'إنشاء'; ?> cstm_inv</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.rtl.min.css" rel="stylesheet">
    <!-- <link href="assets/css/style.css" rel="stylesheet"> -->
    <link href="<?= MY_CSS ?>/cstm_inv.css" rel="stylesheet">
</head>

<body>
    <div class="container py-4 py-lg-5">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
            <div>
                <h1 class="h3 mb-1"><?php echo $id ? 'تعديل' : 'إنشاء'; ?> فاتورة عميل</h1>
                <div class="text-secondary">في هذه النسخة يوجد عرض بعد الحفظ، تعديل كامل، وحذف فوري للعناصر والأصناف والأجزاء.</div>
                <br>
                <br>
                <div class="card mt-3">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <label>إجمالي المتر المكعب</label>
                                <input type="text" id="total_m3" class="form-control" readonly>
                            </div>

                            <div class="col-md-6">
                                <label>إجمالي الوزن</label>
                                <input type="text" id="total_kg" class="form-control" readonly>
                            </div>
                        </div>
                    </div>
                </div>

                <br>
                <br>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <?php if ($id): ?>
                    <a href="view_cstm_inv.php?id=<?php echo $id; ?>" class="btn btn-outline-primary rounded-pill px-4">عرض الفاتورة</a>
                <?php endif; ?>
                <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4">كل الفواتير</a>
            </div>
        </div>

        <div id="alertBox"></div>

        <form id="invoiceForm" data-edit-id="<?php echo $id; ?>">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="row g-4">
                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4">
                            <h2 class="h5 mb-3">بيانات الفاتورة</h2>
                            <div class="row g-3">


                                <div class="col-md-3">
                                    <label class="form-label">العملة</label>
                                    <select class="form-select" name="coin_id">
                                        <!-- <option value="">اختر العملة</option> -->
                                        <?php foreach ($coins as $coin): 
                                            if($coin['is_main'] == 1){
                                            ?>
                                            
                                            <option value="<?php echo (int)$coin['id']; ?>" <?php  echo (!empty($invoice['coin_id']) && (int)$invoice['coin_id'] === (int)$coin['id']) ? 'selected' : ''; ?> selected ><?php echo h($coin['name'] . ' (' . $coin['code'] . ')'); ?></option>
                                        <?php } endforeach; ?>
                                    </select>
                                </div>
                                        <div class="col-md-3">
                                    <input type="hidden"  min="0" class="form-control" name="amount" value="<?php echo h((int)$invoice['amount'] ?? 0); ?>">
                                    <label class="form-label">المدفوع</label>
                                    <input type="number" step="0.01" min="0" class="form-control" name="paid" value="<?php echo h((int)$invoice['paid'] ?? 0); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">ملاحظة</label>
                                    <textarea class="form-control" name="note" rows="2"><?php echo h($invoice['note'] ?? ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-xl-6">
                    <div class="card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <h2 class="h5 mb-3">المرسل</h2>
                            <label class="form-label">اسم المرسل</label>
                            <select class="form-select customer-select" id="send_customer_select" name="cstm_id_send" data-new-box="#send_new_customer_box" data-name-prefix="send_new">
                                <?php if ($selectedSend): ?>
                                    <option value="<?php echo (int)$selectedSend['id']; ?>" selected><?php echo h($selectedSend['text']); ?></option>
                                <?php endif; ?>
                            </select>
                            <div class="form-text text-success mt-1" id="send_customer_status"><?php echo $selectedSend ? 'تم اختيار عميل موجود.' : ''; ?></div>
                            <div class="new-customer-box mt-3 <?php echo $selectedSend ? 'd-none' : ''; ?>" id="send_new_customer_box">
                                <div class="alert alert-warning py-2">إذا لم تجد الاسم، أدخل بيانات عميل جديد.</div>
                                <div class="row g-3">
                                    <div class="col-md-6"><label class="form-label">الاسم يالعربي</label><input type="text" class="form-control" name="send_new[name_ar]"></div>
                                    <div class="col-md-6"><label class="form-label">الاسم بالانجليزي</label><input type="text" class="form-control" name="send_new[name_en]"></div>
                                    <div class="col-md-6"><label class="form-label">الولاية</label><select class="form-select state-select" name="send_new[state_id]"></select></div>
                                    <div class="col-md-6"><label class="form-label">ايميل</label><input type="email" class="form-control" name="send_new[email]"></div>
                                    <div class="col-md-6"><label class="form-label">رقم الهاتف 1</label><input type="text" class="form-control" name="send_new[phone1]"></div>
                                    <div class="col-md-6"><label class="form-label">رقم الهاتف 2</label><input type="text" class="form-control" name="send_new[phone2]"></div>
                                    <div class="col-md-6"><label class="form-label">وصف العنوان</label><input type="text" class="form-control" name="send_new[address]"></div>
                                    <div class="col-md-6"><label class="form-label">الموقع (Location)</label><input type="text" class="form-control" name="send_new[location]"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-xl-6">
                    <div class="card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body p-4">
                            <h2 class="h5 mb-3">المستلم</h2>
                            <label class="form-label">اسم المستلم</label>
                            <select class="form-select customer-select" id="receive_customer_select" name="cstm_id_receive" data-new-box="#receive_new_customer_box" data-name-prefix="receive_new">
                                <?php if ($selectedReceive): ?>
                                    <option value="<?php echo (int)$selectedReceive['id']; ?>" selected><?php echo h($selectedReceive['text']); ?></option>
                                <?php endif; ?>
                            </select>
                            <div class="form-text text-success mt-1" id="receive_customer_status"><?php echo $selectedReceive ? 'تم اختيار عميل موجود.' : ''; ?></div>
                            <div class="new-customer-box mt-3 <?php echo $selectedReceive ? 'd-none' : ''; ?>" id="receive_new_customer_box">
                                <div class="alert alert-warning py-2">إذا لم تجد الاسم، أدخل بيانات عميل جديد.</div>
                                <div class="row g-3">
                                    <div class="col-md-6"><label class="form-label">اسم العميل بالعربي </label><input type="text" class="form-control" name="receive_new[name_ar]"></div>
                                    <div class="col-md-6"><label class="form-label"> اسم العميل بالإنجليزي </label><input type="text" class="form-control" name="receive_new[name_en]"></div>
                                    <div class="col-md-6"><label class="form-label">الولاية</label><select class="form-select state-select" name="receive_new[state_id]"></select></div>
                                    <div class="col-md-6"><label class="form-label">ايميل</label><input type="email" class="form-control" name="receive_new[email]"></div>
                                    <div class="col-md-6"><label class="form-label">رقم الهاتف 1</label><input type="text" class="form-control" name="receive_new[phone1]"></div>
                                    <div class="col-md-6"><label class="form-label">رقم الهاتف 2</label><input type="text" class="form-control" name="receive_new[phone2]"></div>
                                    <div class="col-md-6"><label class="form-label">وصف العنوان</label><input type="text" class="form-control" name="receive_new[address]"></div>
                                    <div class="col-md-6"><label class="form-label">الموقع (Location)</label><input type="text" class="form-control" name="receive_new[location]"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4">
                            <h2 class="h5 mb-3">الولايات</h2>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">من مدينة(ولاية)</label>
                                    <select class="form-select state-select required-state" id="state_id_from" name="state_id_from" data-placeholder="ابحث باسم الولاية أو الكود">
                                        <?php if ($selectedStateFrom): ?>
                                            <option value="<?php echo (int)$selectedStateFrom['id']; ?>" selected><?php echo h($selectedStateFrom['text']); ?></option>
                                        <?php endif; ?>
                                    </select>
                                    <div class="invalid-state-message text-danger small mt-1"></div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">الى مدينة(ولاية)</label>
                                    <select class="form-select state-select required-state" id="state_id_to" name="state_id_to" data-placeholder="ابحث باسم الولاية أو الكود">
                                        <?php if ($selectedStateTo): ?>
                                            <option value="<?php echo (int)$selectedStateTo['id']; ?>" selected><?php echo h($selectedStateTo['text']); ?></option>
                                        <?php endif; ?>
                                    </select>
                                    <div class="invalid-state-message text-danger small mt-1"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                                <h2 class="h5 mb-0">العناصر </h2>
                                <button type="button" class="btn btn-primary" id="addItemBtn"><i class="bi bi-plus-circle"></i> إضافة عنصر</button>
                            </div>
                            <div id="itemsContainer"></div>
                        </div>
                    </div>
                </div>

                <div class="col-12 d-flex gap-2 justify-content-end flex-wrap">
                    <a href="index.php" class="btn btn-outline-secondary px-4">رجوع</a>
                    <button type="submit" class="btn btn-success px-4" id="saveBtn"><?php echo $id ? 'حفظ التعديلات' : 'حفظ الفاتورة'; ?></button>
                </div>
            </div>
        </form>
    </div>

    <script>
        window.COINS = <?php echo json_encode($coins, JSON_UNESCAPED_UNICODE); ?>;
        window.INVOICE_DATA = <?php echo json_encode($invoice, JSON_UNESCAPED_UNICODE); ?>;
    </script>
<!-- D:\xampp\htdocs\00_my_projects\05_transport\app\pages\cstm_inv\create_cstm_inv.php -->
    <template id="itemTemplate">
        <div class="item-card card border-0 shadow-sm rounded-4 mb-3" data-id="">
            <div class="card-body p-3 p-lg-4">
                <div class="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
                    <h3 class="h6 mb-0">عنصر فاتورة</h3>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-sm btn-outline-primary add-class-btn">إضافة صنف</button>
                        <button type="button" class="btn btn-sm btn-outline-danger remove-item-btn">حذف العنصر</button>
                    </div>
                </div>
                <div class="row g-3">
                    <!-- <div class="col-md-3"><label class="form-label">inv_num</label><input type="text" class="form-control item-inv-num"></div> -->
                    <!-- <div class="col-md-3"><label class="form-label">coin_id</label><select class="form-select item-coin-id"></select></div> -->
                    <div class="col-md-3"><label class="form-label">
الاسم بالعربي
</label><input type="text" class="form-control item-name-ar"></div>
                    <div class="col-md-3"><label class="form-label">الاسم بالانجليزي</label><input type="text" class="form-control item-name-en"></div>
                    <!-- <div class="col-md-3"><label class="form-label">dt</label><input type="datetime-local" class="form-control item-dt"></div> -->
                    
                    <div class="col-md-3"><label class="form-label">ملاحظة</label><input type="text" class="form-control item-note"></div>
                </div>
                <div class="classes-container mt-3"></div>
            </div>
        </div>
    </template>

    <template id="classTemplate">
        <div class="class-card card border rounded-4 mt-3" data-id="">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
                    <h4 class="h6 mb-0">الصنف</h4>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-sm btn-outline-primary add-part-btn">إضافة قطعة</button>
                        <button type="button" class="btn btn-sm btn-outline-danger remove-class-btn">حذف الصنف</button>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col-md-3"><label class="form-label">الإسم بالعربي</label><input type="text" class="form-control class-name-ar"></div>
                    <div class="col-md-3"><label class="form-label">الإسم بالإنجليزي</label><input type="text" class="form-control class-name-en"></div>
                    <div class="col-md-3"><label class="form-label">وحدة القياس</label><select class="form-select class-unit">
                            <option value="m3">متر مكعب</option>
                            <option value="kg">كيلوجرام</option>
                        </select></div>
                    <div class="col-md-3"><label class="form-label">ملاحظة</label><input type="text" class="form-control class-note"></div>
                </div>
                <div class="parts-container mt-3"></div>
            </div>
        </div>
    </template>

    <template id="partTemplate">
        <div class="part-row border rounded-4 p-3 mt-3 bg-light" data-id="">
            <div class="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
                <div class="fw-semibold">القطع</div>
                <button type="button" class="btn btn-sm btn-outline-danger remove-part-btn">حذف القطعة</button>
            </div>
            <div class="row g-3">
                <div class="col-md-2"><label class="form-label">العدد</label><input type="number" min="1" class="form-control part-qty" value="1"></div>
                <div class="col-md-2"><label class="form-label">الإرتفاع</label><input type="number" step="0.01" min="0" class="form-control part-height"></div>
                <div class="col-md-2"><label class="form-label">الطول</label><input type="number" step="0.01" min="0" class="form-control part-length"></div>
                <div class="col-md-2"><label class="form-label">العرض</label><input type="number" step="0.01" min="0" class="form-control part-width"></div>
                <div class="col-md-2"><label class="form-label">الوزن</label><input type="number" step="0.01" min="0" class="form-control part-kg"></div>
                <div class="col-md-2"><label class="form-label">ملاحظة</label><input type="text" class="form-control part-note"></div>
            </div>
        </div>
    </template>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <!-- <script src="assets/js/cstm_inv_v2.js"></script> -->

    <script>
        const form = document.getElementById('invoiceForm');
        const alertBox = document.getElementById('alertBox');
        const itemsContainer = document.getElementById('itemsContainer');
        const addItemBtn = document.getElementById('addItemBtn');
        const coins = Array.isArray(window.COINS) ? window.COINS : [];
        const invoiceData = window.INVOICE_DATA || null;

        function showAlert(message, type = 'success') {
            alertBox.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show rounded-4" role="alert">
            <div class="white-space-pre-line">${message}</div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>`;
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }

        function escapeHtml(value) {
            const div = document.createElement('div');
            div.textContent = value ?? '';
            return div.innerHTML;
        }

        function createCoinOptions(selected = '') {
            let html = '<option value="">بدون</option>';
            coins.forEach(coin => {
                const isSelected = String(selected) === String(coin.id) ? 'selected' : '';
                html += `<option value="${coin.id}" ${isSelected}>${escapeHtml(coin.name)} (${escapeHtml(coin.code)})</option>`;
            });
            return html;
        }

        function initAjaxSelect($el, url, placeholder, options = {}) {
            $el.select2({
                theme: 'bootstrap-5',
                dir: 'rtl',
                width: '100%',
                placeholder,
                allowClear: true,
                ajax: {
                    url,
                    dataType: 'json',
                    delay: 250,
                    data: params => ({
                        q: params.term || '',
                        page: params.page || 1
                    }),
                    processResults: data => data,
                    cache: true
                },
                minimumInputLength: options.minimumInputLength ?? 1,
                language: {
                    inputTooShort: () => 'اكتب للبحث',
                    noResults: () => 'لا توجد نتائج'
                }
            });
        }

        function initCustomerSelect(select) {
            const $select = $(select);
            initAjaxSelect($select, '<?= LIBS_URL ?>/ajax/search_cstms.php', 'ابحث عن عميل', {
                minimumInputLength: 1
            });
            const newBox = document.querySelector(select.dataset.newBox);
            const statusId = select.id === 'send_customer_select' ? 'send_customer_status' : 'receive_customer_status';
            const status = document.getElementById(statusId);

            $select.on('select2:clear', () => {
                newBox.classList.remove('d-none');
                status.textContent = 'الاسم غير موجود. أدخل بيانات عميل جديد.';
                status.className = 'form-text text-danger mt-1';
            });

            $select.on('select2:select', () => {
                newBox.classList.add('d-none');
                status.textContent = 'تم اختيار عميل موجود.';
                status.className = 'form-text text-success mt-1';
            });

            if (!$select.val()) {
                newBox.classList.remove('d-none');
            }
        }

        function initStateSelect(select, placeholder = 'ابحث باسم الولاية أو الكود') {
            const $select = $(select);
            initAjaxSelect($select, '<?= LIBS_URL ?>/ajax/search_states.php', placeholder, {
                minimumInputLength: 0
            });

            $select.on('select2:open', () => {
                const searchField = document.querySelector('.select2-container--open .select2-search__field');
                if (searchField) {
                    searchField.placeholder = 'اكتب اسم الولاية أو الكود';
                }
            });

            $select.on('select2:clear', () => validateStateSelect(select));
            $select.on('select2:select', () => validateStateSelect(select));

            $select.on('change', () => validateStateSelect(select));

            $select.on('select2:opening', () => {
                setTimeout(() => {
                    const searchField = document.querySelector('.select2-container--open .select2-search__field');
                    if (searchField && searchField.value.trim() === '') {
                        searchField.dispatchEvent(new Event('input', {
                            bubbles: true
                        }));
                    }
                }, 0);
            });
        }

        function validateStateSelect(select) {
            const messageBox = select.closest('.col-md-6, .col-md-12, .col-lg-6')?.querySelector('.invalid-state-message');
            if (!messageBox) return true;
            if (!select.value) {
                messageBox.textContent = 'لا توجد ولاية بهذا الاسم.';
                return false;
            }
            messageBox.textContent = '';
            return true;
        }

        async function deleteExistingNode(type, id) {
            const formData = new FormData();
            formData.append('type', type);
            formData.append('id', id);
            const res = await fetch('<?= LIBS_URL ?>/ajax/delete_node.php', {
                method: 'POST',
                body: formData
            });
            return res.json();
        }

        function buildPartElement(data = {}) {
            const part = document.getElementById('partTemplate').content.firstElementChild.cloneNode(true);
            if (data.id) part.dataset.id = data.id;
            part.querySelector('.part-qty').value = data.qty ?? 1;
            part.querySelector('.part-height').value = data.height ?? '';
            part.querySelector('.part-length').value = data.length ?? '';
            part.querySelector('.part-width').value = data.width ?? '';
            part.querySelector('.part-kg').value = data.kg ?? '';
            part.querySelector('.part-note').value = data.note ?? '';

            part.querySelector('.remove-part-btn').addEventListener('click', async () => {
                const id = part.dataset.id;
                if (id) {
                    if (!confirm('حذف هذا part من قاعدة البيانات؟')) return;
                    const data = await deleteExistingNode('part', id);
                    if (!data.success) {
                        showAlert(data.message || 'فشل حذف part.', 'danger');
                        return;
                    }
                }
                part.remove();
            });
            return part;
        }

        function buildClassElement(data = {}) {
            const classEl = document.getElementById('classTemplate').content.firstElementChild.cloneNode(true);
            if (data.id) classEl.dataset.id = data.id;
            classEl.querySelector('.class-name-ar').value = data.name_ar ?? '';
            classEl.querySelector('.class-name-en').value = data.name_en ?? '';
            classEl.querySelector('.class-unit').value = data.unit ?? 'm3';
            classEl.querySelector('.class-note').value = data.note ?? '';

            const partsContainer = classEl.querySelector('.parts-container');
            classEl.querySelector('.add-part-btn').addEventListener('click', () => partsContainer.appendChild(buildPartElement()));
            classEl.querySelector('.remove-class-btn').addEventListener('click', async () => {
                const id = classEl.dataset.id;
                if (id) {
                    if (!confirm('حذف هذا class وكل أجزائه؟')) return;
                    const data = await deleteExistingNode('class', id);
                    if (!data.success) {
                        showAlert(data.message || 'فشل حذف class.', 'danger');
                        return;
                    }
                }
                classEl.remove();
            });

            const parts = Array.isArray(data.parts) && data.parts.length ? data.parts : [{}];
            parts.forEach(part => partsContainer.appendChild(buildPartElement(part)));
            return classEl;
        }

        function buildItemElement(data = {}) {
            const itemEl = document.getElementById('itemTemplate').content.firstElementChild.cloneNode(true);
            if (data.id) itemEl.dataset.id = data.id;
            // itemEl.querySelector('.item-coin-id').innerHTML = createCoinOptions(data.coin_id ?? '');
            // itemEl.querySelector('.item-inv-num').value = data.inv_num ?? '';
            itemEl.querySelector('.item-name-ar').value = data.name_ar ?? '';
            itemEl.querySelector('.item-name-en').value = data.name_en ?? '';
            // itemEl.querySelector('.item-dt').value = data.dt ? String(data.dt).replace(' ', 'T').slice(0, 16) : new Date().toISOString().slice(0, 16);
            // itemEl.querySelector('.item-amount').value = data.amount ?? 0;
            // itemEl.querySelector('.item-paid').value = data.paid ?? 0;
            itemEl.querySelector('.item-note').value = data.note ?? '';

            const classesContainer = itemEl.querySelector('.classes-container');
            itemEl.querySelector('.add-class-btn').addEventListener('click', () => classesContainer.appendChild(buildClassElement()));
            itemEl.querySelector('.remove-item-btn').addEventListener('click', async () => {
                const id = itemEl.dataset.id;
                if (id) {
                    if (!confirm('حذف هذا العنصر مع كل الأصناف والأجزاء؟')) return;
                    const data = await deleteExistingNode('item', id);
                    if (!data.success) {
                        showAlert(data.message || 'فشل حذف العنصر.', 'danger');
                        return;
                    }
                }
                itemEl.remove();
            });

            const classes = Array.isArray(data.classes) && data.classes.length ? data.classes : [{}];
            classes.forEach(cls => classesContainer.appendChild(buildClassElement(cls)));
            return itemEl;
        }

        function collectNestedData() {
            return Array.from(itemsContainer.querySelectorAll('.item-card')).map(itemEl => ({
                id: itemEl.dataset.id || '',
                // inv_num: itemEl.querySelector('.item-inv-num').value.trim(),
                // coin_id: itemEl.querySelector('.item-coin-id').value,
                name_ar: itemEl.querySelector('.item-name-ar').value.trim(),
                name_en: itemEl.querySelector('.item-name-en').value.trim(),
                // dt: itemEl.querySelector('.item-dt').value,
                // amount: itemEl.querySelector('.item-amount').value,
                // paid: itemEl.querySelector('.item-paid').value,
                note: itemEl.querySelector('.item-note').value.trim(),
                classes: Array.from(itemEl.querySelectorAll('.class-card')).map(classEl => ({
                    id: classEl.dataset.id || '',
                    name_ar: classEl.querySelector('.class-name-ar').value.trim(),
                    name_en: classEl.querySelector('.class-name-en').value.trim(),
                    unit: classEl.querySelector('.class-unit').value,
                    note: classEl.querySelector('.class-note').value.trim(),
                    parts: Array.from(classEl.querySelectorAll('.part-row')).map(partEl => ({
                        id: partEl.dataset.id || '',
                        qty: partEl.querySelector('.part-qty').value,
                        height: partEl.querySelector('.part-height').value,
                        length: partEl.querySelector('.part-length').value,
                        width: partEl.querySelector('.part-width').value,
                        kg: partEl.querySelector('.part-kg').value,
                        note: partEl.querySelector('.part-note').value.trim(),
                    }))
                }))
            }));
        }

        function validateForm() {
            let ok = true;
            document.querySelectorAll('.required-state').forEach(select => {
                if (!validateStateSelect(select)) ok = false;
            });
            if (!itemsContainer.querySelector('.item-card')) {
                showAlert('أضف عنصراً واحداً على الأقل.', 'danger');
                ok = false;
            }
            return ok;
        }

        async function submitForm(e) {
            e.preventDefault();
            if (!validateForm()) return;

            const saveBtn = document.getElementById('saveBtn');
            saveBtn.disabled = true;
            const oldText = saveBtn.textContent;
            saveBtn.textContent = 'جاري الحفظ...';

            try {
                const formData = new FormData(form);
                formData.append('nested_data', JSON.stringify(collectNestedData()));

                const res = await fetch('<?= LIBS_URL ?>/ajax/save_cstm_inv.php', {
                    method: 'POST',
                    body: formData,
                });
                const data = await res.json();

                if (!data.success) {
                    showAlert(data.message || 'فشل الحفظ.', 'danger');
                    return;
                }

                showAlert(`${data.message}<br><a href="inv_sel_price.php?id=${data.cstm_inv_id}" class="alert-link">فتح الفاتورة الآن</a>`, 'success');
                setTimeout(() => {
                    window.location.href = `inv_sel_price.php?id=${data.cstm_inv_id}`;
                }, 900);
            } catch (err) {
                showAlert('حدث خطأ أثناء الحفظ.', 'danger');
            } finally {
                saveBtn.disabled = false;
                saveBtn.textContent = oldText;
            }
        }

        function bootExistingData() {
            if (invoiceData && Array.isArray(invoiceData.items) && invoiceData.items.length) {
                invoiceData.items.forEach(item => itemsContainer.appendChild(buildItemElement(item)));
            } else {
                itemsContainer.appendChild(buildItemElement());
            }
        }

        $(function() {
            document.querySelectorAll('.customer-select').forEach(initCustomerSelect);
            document.querySelectorAll('.state-select').forEach(select => {
                initStateSelect(select, select.dataset.placeholder || 'ابحث عن ولاية');
                validateStateSelect(select);
            });
            addItemBtn.addEventListener('click', () => itemsContainer.appendChild(buildItemElement()));
            form.addEventListener('submit', submitForm);
            bootExistingData();
        });


















        // Units

        



function calculateTotals(){

    let totalM3 = 0;
    let totalKG = 0;

    document.querySelectorAll(".class-card").forEach(classCard => {

        const unit = classCard.querySelector(".class-unit")?.value;

        if(!unit) return;

        classCard.querySelectorAll(".part-row").forEach(part => {

            if(unit === "m3"){

                const l = parseFloat(part.querySelector(".part-length")?.value) || 0;
                const w = parseFloat(part.querySelector(".part-width")?.value) || 0;
                const h = parseFloat(part.querySelector(".part-height")?.value) || 0;

                const volume = l * w * h;

                totalM3 += volume;
            }

            if(unit === "kg"){

                const weight = parseFloat(part.querySelector(".part-weight")?.value) || 0;

                totalKG += weight;
            }

        });

    });

    document.getElementById("total_m3").value = totalM3.toFixed(3);
    document.getElementById("total_kg").value = totalKG.toFixed(2);

}












document.addEventListener("input", function(e){

    if(
        e.target.classList.contains("part-length") ||
        e.target.classList.contains("part-width") ||
        e.target.classList.contains("part-height") ||
        e.target.classList.contains("part-weight") ||
        e.target.classList.contains("class-unit")
    ){
        calculateTotals();
    }

});











calculateTotals();



    </script>
</body>

</html>