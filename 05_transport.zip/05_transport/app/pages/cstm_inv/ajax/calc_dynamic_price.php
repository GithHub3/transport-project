


<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../../../config.php';
require_once LIBS . '/query/config.php';


try {
    $pdo = db_conn();

    $from_country_id = (int)($_POST['from_country_id'] ?? 0);
    $to_country_id   = (int)($_POST['to_country_id'] ?? 0);
    $total_m3        = (float)($_POST['total_m3'] ?? 0);
    $total_kg        = (float)($_POST['total_kg'] ?? 0);

    if ($from_country_id <= 0 || $to_country_id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'بيانات الدول غير مكتملة'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT 
            p.id,
            p.coin_id,
            p.min_price_m3,
            p.max_price_m3,
            p.min_price_kg,
            p.max_price_kg,
            c.name_ar AS coin_name_ar,
            c.name_en AS coin_name_en,
            c.code AS coin_code
        FROM prices p
        LEFT JOIN coins c ON c.id = p.coin_id
        WHERE p.from_country_id = :from_country_id
          AND p.to_country_id = :to_country_id
        LIMIT 1
    ");

    $stmt->execute([
        ':from_country_id' => $from_country_id,
        ':to_country_id'   => $to_country_id
    ]);

    $priceRow = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$priceRow) {
        echo json_encode([
            'success' => false,
            'message' => 'لا توجد أسعار لهذه الوجهة'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $min_price_m3 = (float)$priceRow['min_price_m3'];
    $max_price_m3 = (float)$priceRow['max_price_m3'];
    $min_price_kg = (float)$priceRow['min_price_kg'];
    $max_price_kg = (float)$priceRow['max_price_kg'];

    $min_total_price = ($total_m3 * $min_price_m3) + ($total_kg * $min_price_kg);
    $max_total_price = ($total_m3 * $max_price_m3) + ($total_kg * $max_price_kg);

    $coinLabel = '';
    if (!empty($priceRow['coin_code'])) {
        $coinLabel = $priceRow['coin_code'];
    } elseif (!empty($priceRow['coin_name_ar'])) {
        $coinLabel = $priceRow['coin_name_ar'];
    } elseif (!empty($priceRow['coin_name_en'])) {
        $coinLabel = $priceRow['coin_name_en'];
    }

    echo json_encode([
        'success' => true,
        'total_m3' => number_format($total_m3, 3, '.', ''),
        'total_kg' => number_format($total_kg, 2, '.', ''),
        'min_price_m3' => number_format($min_price_m3, 2, '.', ''),
        'max_price_m3' => number_format($max_price_m3, 2, '.', ''),
        'min_price_kg' => number_format($min_price_kg, 2, '.', ''),
        'max_price_kg' => number_format($max_price_kg, 2, '.', ''),
        'min_total_price' => number_format($min_total_price, 2, '.', '') . ($coinLabel ? ' ' . $coinLabel : ''),
        'max_total_price' => number_format($max_total_price, 2, '.', '') . ($coinLabel ? ' ' . $coinLabel : ''),
        'coin_id' => (int)$priceRow['coin_id'],
        'coin_label' => $coinLabel,
        'message' => 'تم حساب السعر بنجاح'
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في الخادم: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}