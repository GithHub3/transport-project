<?php
require_once __DIR__ . '/../../../../config.php';


require_once SEC_PATH . '/forms.php';


require_once CRUD_PATH;

$crud = new CRUD();

$all_errors = " ";

//قيد التعديل


// التحقق من CSRF
if (!FormSecurity::validateCsrfToken($_POST['csrf_token'])) {
    die('طلب غير مصرح به (CSRF)');
}

// (اختياري) إزالة token بعد الاستخدام لمنع إعادة الاستخدام
FormSecurity::removeCsrfToken();

// التحقق من صحة البيانات
$errors = [];






if (empty($_POST['inv_id'])) {
    $errors[] = 'يوجد خطأ  .';
}else{$id = (int)$_POST['inv_id'];}

if (empty($_POST['amount']) || $_POST['amount'] < 0) {
    $errors[] = 'يوجد خطأ  .';
}else{$amount = (int)$_POST['amount'];}

if (empty($_POST['paid'])  || $_POST['paid'] < 0) {
    $errors[] = 'يوجد خطأ  .';
}else{$paid = (int)$_POST['paid'];}


// إذا لا توجد أخطاء، قم بمعالجة البيانات (مثلاً الإدخال في قاعدة البيانات)
if (empty($errors)) {

    $result = $crud->update('cstm_inv', ['amount' => $amount ,'paid' => $paid ],['id' => $id]);



    if (!$result) {
        echo '<script>
    alert(" يوجد  خطأ !! ");
    window.location.href = "../inv_sel_price.php?id='.$id.' "; 
</script>
';
        exit;
    } else {
     echo '<script>
    alert(" تم بنجاح ");
    window.location.href = "../view_cstm_inv.php?id='.$id.' "; 
</script>
';
     
        exit;
    }
} else {
    // عرض الأخطاء
    foreach ($errors as $error) {
        echo '<p style="color:red">' . FormSecurity::escape($error) . '</p>';

        // $all_errors .= FormSecurity::escape($error) . " \n ";
    }
    //     echo '<script>
    //     alert(" ' . $all_errors . '  ");
    // window.location.href = "../login.php"; 
    // </script>
    //   ';
    exit;
}

exit;

