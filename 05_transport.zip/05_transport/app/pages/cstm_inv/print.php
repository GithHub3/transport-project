<?php
require_once __DIR__ . '/../../../config.php';
require_once MY_LIBS . '/lib_invoice.php';
$coins = get_coins();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$invoice = get_invoice_full($id);
if (!$invoice) {
    http_response_code(404);
    echo 'الفاتورة غير موجودة';
    exit;
}




?>


<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تفاصيل الطرود</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Tahoma, Arial, sans-serif;
            background: #e9e9e9;
            color: #000;
            padding: 20px;
        }

        .page {
            width: 210mm;
            min-height: 297mm;
            background: #fff;
            margin: 0 auto;
            padding: 10mm;
            border: 1px solid #ccc;
        }

        .top-bar {
            height: 18px;
            background: linear-gradient(to left, #2f7cc0 0 14%, #1c0d63 14% 100%);
            margin-bottom: 10px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }

        .header-box {
            width: 32%;
            min-height: 95px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .header-left {
            text-align: right;
            font-size: 14px;
            line-height: 1.8;
        }

        .header-center {
            align-items: center;
            text-align: center;
        }

        .logo {
            width: 90px;
            height: 90px;
            border: 4px solid #2f7cc0;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            font-weight: bold;
            color: #1c0d63;
        }

        .header-right {
            text-align: right;
            font-size: 14px;
            line-height: 1.7;
            font-weight: bold;
        }

        .separator {
            border-top: 3px double #7685a5;
            margin: 8px 0 14px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 10px;
        }

        .small-stack {
            width: 30%;
        }

        .middle-stack {
            width: 10%;
            text-align: center;
            font-size: 20px;
            line-height: 1.7;
            padding-top: 8px;
        }

        .box {
            border: 2px solid #000;
            margin-bottom: 8px;
        }

        .box table {
            width: 100%;
            border-collapse: collapse;
        }

        .box td {
            border: 2px solid #000;
            padding: 6px 8px;
            font-size: 16px;
            font-weight: bold;
            vertical-align: middle;
        }

        .title-center {
            width: 240px;
            margin: 10px auto 14px;
            text-align: center;
            border: 2px solid #000;
            padding: 6px 10px;
            font-size: 20px;
            font-weight: bold;
        }

        table.main {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }

        table.main th,
        table.main td {
            border: 2px solid #000;
            text-align: center;
            vertical-align: middle;
            padding: 4px 3px;
            font-size: 14px;
            height: 42px;
            word-wrap: break-word;
        }

        table.main th {
            font-weight: bold;
        }

        .subhead {
            font-size: 12px;
        }

        .notes-green {
            background: #a8cf87;
            font-weight: bold;
        }

        .summary {
            width: 300px;
            margin-top: 18px;
        }

        .summary table {
            width: 100%;
            border-collapse: collapse;
        }

        .summary td {
            border: 2px solid #000;
            padding: 6px 8px;
            font-size: 18px;
            font-weight: bold;
        }

        .footer {
            margin-top: 16px;
            display: flex;
            align-items: center;
            color: #fff;
            font-size: 14px;
            font-weight: bold;
        }

        .footer-left {
            width: 12%;
            height: 34px;
            background: #2f7cc0;
        }

        .footer-right {
            width: 88%;
            background: #1c0d63;
            min-height: 34px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 6px 10px;
            line-height: 1.6;
        }

        .text-right {
            text-align: right;
        }

        .text-left {
            text-align: left;
        }

        .w-no {
            width: 4%;
        }

        .w-type {
            width: 15%;
        }

        .w-item {
            width: 19%;
        }

        .w-count {
            width: 8%;
        }

        .w-l {
            width: 8%;
        }

        .w-w {
            width: 8%;
        }

        .w-h {
            width: 8%;
        }

        .w-total {
            width: 8%;
        }

        .w-kg {
            width: 9%;
        }

        .w-note {
            width: 11%;
        }

        @media print {
            body {
                background: #fff;
                padding: 0;
            }

            .page {
                border: none;
                margin: 0;
                width: 210mm;
                min-height: auto;
                padding: 8mm;
            }

            @page {
                size: A4;
                margin: 0;
            }
        }
    </style>
</head>

<body>

    <div class="page">

        <div class="top-bar"></div>

        <div class="header">
            <div class="header-box header-left">
                <div style="font-size:18px;font-weight:bold;">فرست تشويز للاستيراد و التصدير</div>
                <div style="color:#2f7cc0;font-size:16px;font-weight:bold;">First Choice For Importing & Exporting</div>
            </div>

            <div class="header-box header-center">
                <div class="logo">LOGO</div>
            </div>

            <div class="header-box header-right">
                <div>Phone Number : 00967 77 886 6277</div>
                <div>Email Address : firstchoico@gmail.com</div>
                <div>Address : Al-mohafza st , Sanaa , Yemen</div>
            </div>
        </div>

        <div class="separator"></div>

        <div class="info-row">
            <div class="small-stack">
                <div class="box">
                    <table>
                        <tr>
                            <td style="width:65%;">مستلم الشحنة: سامي عبيد (ذهبي)</td>
                        </tr>
                        <tr>
                            <td>رقمه: +1(209) 606 8359 ، رقم الفاتورة: 0072</td>
                        </tr>
                    </table>
                </div>
            </div>

            <div class="middle-stack">
                <div>1</div>
                <div>فرع /</div>
            </div>

            <div class="small-stack">
                <div class="box">
                    <table>
                        <tr>
                            <td style="width:35%;">شحنة ولاية :</td>
                            <td class="text-left">CALFORNIA</td>
                        </tr>
                        <tr>
                            <td>كود الشحنة:</td>
                            <td class="text-left">CA1106</td>
                        </tr>
                    </table>
                </div>

                <div class="box">
                    <table>
                        <tr>
                            <td>تاريخ تفريغ البيانات: 2024 / 5 / 9</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="title-center">تفاصيل الطرود</div>

        <table class="main">
            <thead>
                <tr>
                    <th rowspan="2" class="w-no">م</th>
                    <th rowspan="2" class="w-type">نوع الشحنة</th>
                    <th rowspan="2" class="w-item">نوع الطرد</th>
                    <th rowspan="2" class="w-count">العدد</th>
                    <th colspan="4">مساحة الطرد</th>
                    <th colspan="2">الوزن/ك</th>
                </tr>
                <tr>
                    <th class="w-l subhead">الطول</th>
                    <th class="w-w subhead">العرض</th>
                    <th class="w-h subhead">الارتفاع</th>
                    <th class="w-total subhead">إجمالي م/ك</th>
                    <th class="w-kg subhead">وزن الطرد</th>
                    <th class="w-note subhead">ملاحظات</th>
                </tr>
            </thead>
            <tbody>
               
        
                <?php if (!$invoice['items']): ?>
                    <div class="alert alert-secondary">لا توجد عناصر.</div>
                <?php else:
                    $cntItems = 0;
                ?>
                <tr>
                    <?php foreach ($invoice['items'] as $itemIndex => $item):
                        $cntItems += 1;
                    ?>

                        
                            <td rowspan="<?= itemRow($item['id']) ?>"><?= $cntItems ?></td>
                            <td rowspan="<?= itemRow($item['id']) ?>" style="font-weight:bold; line-height:1.6;">
                                <?= $item['name_en'] ?>
                            </td>
                            <?php foreach ($item['classes'] as $classIndex => $class): ?>

                                <td rowspan="<?= classRow($class['id']) ?>"> <?= $class['name_en'] ?> </td>
                                <?php foreach ($class['parts'] as $partIndex => $part): ?>

                                    <td><?= $part['qty'] ?></td>
                                    <td><?= $part['length'] ?></td>
                                    <td><?= $part['width'] ?></td>
                                    <td><?= $part['height'] ?></td>
                                    <td><?= number_format($part['length'] * $part['width'] * $part['height'], 2) ?></td>
                                    <td><?= $part['kg'] ?></td>
                                    <td > <?= $part['note'] ?> </td>
                                    
                                </tr>
                                <tr>

                                <?php endforeach;  ?>
                                

                <?php endforeach;
                        endforeach; ?>
                        </tr>
            <?php endif; ?>

            </tbody>
        </table>

        <div class="summary">
            <table>
                <tr>
                    <td>إجمالي أبعاد الشحنة M3</td>
                    <td class="text-left">7.416927</td>
                </tr>
                <tr>
                    <td>إجمالي وزن الشحنة Kg</td>
                    <td class="text-left">541.6</td>
                </tr>
                <tr>
                    <td>إجمالي عدد الطرود No:</td>
                    <td class="text-left">10</td>
                </tr>
            </table>
        </div>

        <div class="footer">
            <div class="footer-left"></div>
            <div class="footer-right">
                العنوان : اليمن - صنعاء - بيت بوس - شارع المحافظة ،
                تلفون : 778866977 - 778866277 ،
                الإيميل : firstchoico1@gmail.com
            </div>
        </div>

    </div>


</body>

</html>