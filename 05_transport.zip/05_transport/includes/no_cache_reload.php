<?php

// ✅ رؤوس تمنع الكاش وتحفز إعادة تحميل الصفحة
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
?>

<script>
// ✅ تحديث الصفحة تلقائياً عند العودة بزر الرجوع (Back)
window.addEventListener('pageshow', function (event) {
    if (event.persisted) {
       window.location.reload();
    }
});
</script>
