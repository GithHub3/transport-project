<?php
require_once __DIR__ . '/lib_invoice.php';
$pdo = db_conn();
$stmt = $pdo->query("SELECT i.id, i.inv_num, i.dt, i.amount, i.paid,
    s1.name_ar AS send_name_ar, s1.name_en AS send_name_en,
    s2.name_ar AS receive_name_ar, s2.name_en AS receive_name_en,
    co.code AS coin_code
    FROM cstm_inv i
    LEFT JOIN cstms s1 ON s1.id = i.cstm_id_send
    LEFT JOIN cstms s2 ON s2.id = i.cstm_id_receive
    LEFT JOIN coins co ON co.id = i.coin_id
    ORDER BY i.id DESC");
$rows = $stmt->fetchAll() ?: [];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>فواتير العملاء</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="container py-4 py-lg-5">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">فواتير العملاء</h1>
            <div class="text-secondary">عرض، إنشاء، تعديل، ثم فتح الفاتورة بعد الحفظ.</div>
        </div>
        <a href="create_cstm_inv.php" class="btn btn-primary rounded-pill px-4"><i class="bi bi-plus-circle"></i> فاتورة جديدة</a>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>رقم الفاتورة</th>
                            <th>المرسل</th>
                            <th>المستلم</th>
                            <th>التاريخ</th>
                            <th>المبلغ</th>
                            <th>المدفوع</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$rows): ?>
                            <tr><td colspan="8" class="text-center py-5 text-secondary">لا توجد فواتير بعد.</td></tr>
                        <?php else: ?>
                            <?php foreach ($rows as $row): ?>
                                <tr>
                                    <td><?php echo (int)$row['id']; ?></td>
                                    <td><?php echo h($row['inv_num'] ?: '-'); ?></td>
                                    <td><?php echo h(trim(($row['send_name_ar'] ?: '') . ' ' . ($row['send_name_en'] ?: '')) ?: '-'); ?></td>
                                    <td><?php echo h(trim(($row['receive_name_ar'] ?: '') . ' ' . ($row['receive_name_en'] ?: '')) ?: '-'); ?></td>
                                    <td><?php echo h($row['dt']); ?></td>
                                    <td><?php echo h(number_format((float)$row['amount'], 2)) . ' ' . h($row['coin_code'] ?: ''); ?></td>
                                    <td><?php echo h(number_format((float)$row['paid'], 2)); ?></td>
                                    <td>
                                        <div class="d-flex gap-2 flex-wrap">
                                            <a class="btn btn-sm btn-outline-primary" href="view_cstm_inv.php?id=<?php echo (int)$row['id']; ?>">عرض</a>
                                            <a class="btn btn-sm btn-outline-success" href="create_cstm_inv.php?id=<?php echo (int)$row['id']; ?>">تعديل</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
