<?php
require_once __DIR__ . '/lib_invoice.php';
$coins = get_coins();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$formData = $id ? get_invoice_form_data($id) : null;
if ($id && !$formData) {
    http_response_code(404);
    echo 'الفاتورة غير موجودة';
    exit;
}
$invoice = $formData['invoice'] ?? null;
$selectedSend = $formData['selected_send'] ?? [];
$selectedReceive = $formData['selected_receive'] ?? [];
$selectedStateFrom = $formData['selected_state_from'] ?? [];
$selectedStateTo = $formData['selected_state_to'] ?? [];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $id ? 'تعديل' : 'إنشاء'; ?> cstm_inv</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.rtl.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="container py-4 py-lg-5">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1"><?php echo $id ? 'تعديل' : 'إنشاء'; ?> فاتورة عميل</h1>
            <div class="text-secondary">في هذه النسخة يوجد عرض بعد الحفظ، تعديل كامل، وحذف فوري للعناصر والأصناف والأجزاء.</div>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <?php if ($id): ?>
                <a href="view_cstm_inv.php?id=<?php echo $id; ?>" class="btn btn-outline-primary rounded-pill px-4">عرض الفاتورة</a>
            <?php endif; ?>
            <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4">كل الفواتير</a>
        </div>
    </div>

    <div id="alertBox"></div>

    <form id="invoiceForm" data-edit-id="<?php echo $id; ?>">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <div class="row g-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <h2 class="h5 mb-3">بيانات الفاتورة</h2>
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">رقم الفاتورة</label>
                                <input type="text" class="form-control" name="inv_num" value="<?php echo h($invoice['inv_num'] ?? ''); ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">ship_id</label>
                                <input type="number" min="1" class="form-control" name="ship_id" value="<?php echo h($invoice['ship_id'] ?? ''); ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">العملة</label>
                                <select class="form-select" name="coin_id">
                                    <option value="">اختر العملة</option>
                                    <?php foreach ($coins as $coin): ?>
                                        <option value="<?php echo (int)$coin['id']; ?>" <?php echo (!empty($invoice['coin_id']) && (int)$invoice['coin_id'] === (int)$coin['id']) ? 'selected' : ''; ?>><?php echo h($coin['name'] . ' (' . $coin['code'] . ')'); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">التاريخ والوقت</label>
                                <input type="datetime-local" class="form-control" name="dt" value="<?php echo h(isset($invoice['dt']) ? date('Y-m-d\TH:i', strtotime($invoice['dt'])) : date('Y-m-d\TH:i')); ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">المبلغ</label>
                                <input type="number" step="0.01" min="0" class="form-control" name="amount" value="<?php echo h($invoice['amount'] ?? 0); ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">المدفوع</label>
                                <input type="number" step="0.01" min="0" class="form-control" name="paid" value="<?php echo h($invoice['paid'] ?? 0); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">ملاحظة</label>
                                <textarea class="form-control" name="note" rows="2"><?php echo h($invoice['note'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-xl-6">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-4">
                        <h2 class="h5 mb-3">المرسل</h2>
                        <label class="form-label">اسم المرسل</label>
                        <select class="form-select customer-select" id="send_customer_select" name="cstm_id_send" data-new-box="#send_new_customer_box" data-name-prefix="send_new">
                            <?php if ($selectedSend): ?>
                                <option value="<?php echo (int)$selectedSend['id']; ?>" selected><?php echo h($selectedSend['text']); ?></option>
                            <?php endif; ?>
                        </select>
                        <div class="form-text text-success mt-1" id="send_customer_status"><?php echo $selectedSend ? 'تم اختيار عميل موجود.' : ''; ?></div>
                        <div class="new-customer-box mt-3 <?php echo $selectedSend ? 'd-none' : ''; ?>" id="send_new_customer_box">
                            <div class="alert alert-warning py-2">إذا لم تجد الاسم، أدخل بيانات عميل جديد.</div>
                            <div class="row g-3">
                                <div class="col-md-6"><label class="form-label">name_ar</label><input type="text" class="form-control" name="send_new[name_ar]"></div>
                                <div class="col-md-6"><label class="form-label">name_en</label><input type="text" class="form-control" name="send_new[name_en]"></div>
                                <div class="col-md-6"><label class="form-label">الولاية</label><select class="form-select state-select" name="send_new[state_id]"></select></div>
                                <div class="col-md-6"><label class="form-label">email</label><input type="email" class="form-control" name="send_new[email]"></div>
                                <div class="col-md-6"><label class="form-label">phone1</label><input type="text" class="form-control" name="send_new[phone1]"></div>
                                <div class="col-md-6"><label class="form-label">phone2</label><input type="text" class="form-control" name="send_new[phone2]"></div>
                                <div class="col-md-6"><label class="form-label">address</label><input type="text" class="form-control" name="send_new[address]"></div>
                                <div class="col-md-6"><label class="form-label">location</label><input type="text" class="form-control" name="send_new[location]"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-xl-6">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-4">
                        <h2 class="h5 mb-3">المستلم</h2>
                        <label class="form-label">اسم المستلم</label>
                        <select class="form-select customer-select" id="receive_customer_select" name="cstm_id_receive" data-new-box="#receive_new_customer_box" data-name-prefix="receive_new">
                            <?php if ($selectedReceive): ?>
                                <option value="<?php echo (int)$selectedReceive['id']; ?>" selected><?php echo h($selectedReceive['text']); ?></option>
                            <?php endif; ?>
                        </select>
                        <div class="form-text text-success mt-1" id="receive_customer_status"><?php echo $selectedReceive ? 'تم اختيار عميل موجود.' : ''; ?></div>
                        <div class="new-customer-box mt-3 <?php echo $selectedReceive ? 'd-none' : ''; ?>" id="receive_new_customer_box">
                            <div class="alert alert-warning py-2">إذا لم تجد الاسم، أدخل بيانات عميل جديد.</div>
                            <div class="row g-3">
                                <div class="col-md-6"><label class="form-label">name_ar</label><input type="text" class="form-control" name="receive_new[name_ar]"></div>
                                <div class="col-md-6"><label class="form-label">name_en</label><input type="text" class="form-control" name="receive_new[name_en]"></div>
                                <div class="col-md-6"><label class="form-label">الولاية</label><select class="form-select state-select" name="receive_new[state_id]"></select></div>
                                <div class="col-md-6"><label class="form-label">email</label><input type="email" class="form-control" name="receive_new[email]"></div>
                                <div class="col-md-6"><label class="form-label">phone1</label><input type="text" class="form-control" name="receive_new[phone1]"></div>
                                <div class="col-md-6"><label class="form-label">phone2</label><input type="text" class="form-control" name="receive_new[phone2]"></div>
                                <div class="col-md-6"><label class="form-label">address</label><input type="text" class="form-control" name="receive_new[address]"></div>
                                <div class="col-md-6"><label class="form-label">location</label><input type="text" class="form-control" name="receive_new[location]"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <h2 class="h5 mb-3">الولايات</h2>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">state_id_from</label>
                                <select class="form-select state-select required-state" id="state_id_from" name="state_id_from" data-placeholder="ابحث باسم الولاية أو الكود">
                                    <?php if ($selectedStateFrom): ?>
                                        <option value="<?php echo (int)$selectedStateFrom['id']; ?>" selected><?php echo h($selectedStateFrom['text']); ?></option>
                                    <?php endif; ?>
                                </select>
                                <div class="invalid-state-message text-danger small mt-1"></div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">state_id_to</label>
                                <select class="form-select state-select required-state" id="state_id_to" name="state_id_to" data-placeholder="ابحث باسم الولاية أو الكود">
                                    <?php if ($selectedStateTo): ?>
                                        <option value="<?php echo (int)$selectedStateTo['id']; ?>" selected><?php echo h($selectedStateTo['text']); ?></option>
                                    <?php endif; ?>
                                </select>
                                <div class="invalid-state-message text-danger small mt-1"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                            <h2 class="h5 mb-0">عناصر الفاتورة</h2>
                            <button type="button" class="btn btn-primary" id="addItemBtn"><i class="bi bi-plus-circle"></i> إضافة عنصر</button>
                        </div>
                        <div id="itemsContainer"></div>
                    </div>
                </div>
            </div>

            <div class="col-12 d-flex gap-2 justify-content-end flex-wrap">
                <a href="index.php" class="btn btn-outline-secondary px-4">رجوع</a>
                <button type="submit" class="btn btn-success px-4" id="saveBtn"><?php echo $id ? 'حفظ التعديلات' : 'حفظ الفاتورة'; ?></button>
            </div>
        </div>
    </form>
</div>

<script>
window.COINS = <?php echo json_encode($coins, JSON_UNESCAPED_UNICODE); ?>;
window.INVOICE_DATA = <?php echo json_encode($invoice, JSON_UNESCAPED_UNICODE); ?>;
</script>

<template id="itemTemplate">
    <div class="item-card card border-0 shadow-sm rounded-4 mb-3" data-id="">
        <div class="card-body p-3 p-lg-4">
            <div class="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
                <h3 class="h6 mb-0">عنصر فاتورة</h3>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-sm btn-outline-primary add-class-btn">إضافة class</button>
                    <button type="button" class="btn btn-sm btn-outline-danger remove-item-btn">حذف العنصر</button>
                </div>
            </div>
            <div class="row g-3">
                <div class="col-md-3"><label class="form-label">inv_num</label><input type="text" class="form-control item-inv-num"></div>
                <div class="col-md-3"><label class="form-label">coin_id</label><select class="form-select item-coin-id"></select></div>
                <div class="col-md-3"><label class="form-label">name_ar</label><input type="text" class="form-control item-name-ar"></div>
                <div class="col-md-3"><label class="form-label">name_en</label><input type="text" class="form-control item-name-en"></div>
                <div class="col-md-3"><label class="form-label">dt</label><input type="datetime-local" class="form-control item-dt"></div>
                <div class="col-md-3"><label class="form-label">amount</label><input type="number" step="0.01" min="0" class="form-control item-amount" value="0"></div>
                <div class="col-md-3"><label class="form-label">paid</label><input type="number" step="0.01" min="0" class="form-control item-paid" value="0"></div>
                <div class="col-md-3"><label class="form-label">note</label><input type="text" class="form-control item-note"></div>
            </div>
            <div class="classes-container mt-3"></div>
        </div>
    </div>
</template>

<template id="classTemplate">
    <div class="class-card card border rounded-4 mt-3" data-id="">
        <div class="card-body p-3">
            <div class="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
                <h4 class="h6 mb-0">Class</h4>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-sm btn-outline-primary add-part-btn">إضافة part</button>
                    <button type="button" class="btn btn-sm btn-outline-danger remove-class-btn">حذف class</button>
                </div>
            </div>
            <div class="row g-3">
                <div class="col-md-3"><label class="form-label">name_ar</label><input type="text" class="form-control class-name-ar"></div>
                <div class="col-md-3"><label class="form-label">name_en</label><input type="text" class="form-control class-name-en"></div>
                <div class="col-md-3"><label class="form-label">unit</label><select class="form-select class-unit"><option value="m3">m3</option><option value="kg">kg</option></select></div>
                <div class="col-md-3"><label class="form-label">note</label><input type="text" class="form-control class-note"></div>
            </div>
            <div class="parts-container mt-3"></div>
        </div>
    </div>
</template>

<template id="partTemplate">
    <div class="part-row border rounded-4 p-3 mt-3 bg-light" data-id="">
        <div class="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
            <div class="fw-semibold">Part</div>
            <button type="button" class="btn btn-sm btn-outline-danger remove-part-btn">حذف part</button>
        </div>
        <div class="row g-3">
            <div class="col-md-2"><label class="form-label">qty</label><input type="number" min="1" class="form-control part-qty" value="1"></div>
            <div class="col-md-2"><label class="form-label">height</label><input type="number" step="0.01" min="0" class="form-control part-height"></div>
            <div class="col-md-2"><label class="form-label">length</label><input type="number" step="0.01" min="0" class="form-control part-length"></div>
            <div class="col-md-2"><label class="form-label">width</label><input type="number" step="0.01" min="0" class="form-control part-width"></div>
            <div class="col-md-2"><label class="form-label">kg</label><input type="number" step="0.01" min="0" class="form-control part-kg"></div>
            <div class="col-md-2"><label class="form-label">note</label><input type="text" class="form-control part-note"></div>
        </div>
    </div>
</template>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="assets/js/cstm_inv_v2.js"></script>
</body>
</html>
