<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';

$q = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

$pdo = db_conn();

$sql = "SELECT id, name_ar, name_en, code
        FROM states
        WHERE (:q1 = '' OR name_ar LIKE :like1 OR name_en LIKE :like2 OR code LIKE :like3)
        ORDER BY
            CASE WHEN code = :exact1 THEN 0 ELSE 1 END,
            CASE WHEN name_ar = :exact2 THEN 0 ELSE 1 END,
            CASE WHEN name_en = :exact3 THEN 0 ELSE 1 END,
            name_ar ASC, name_en ASC, code ASC
        LIMIT {$limit} OFFSET {$offset}";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    ':q1'     => $q,
    ':like1'  => "%{$q}%",
    ':like2'  => "%{$q}%",
    ':like3'  => "%{$q}%",
    ':exact1' => $q,
    ':exact2' => $q,
    ':exact3' => $q,
]);

$items = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

$results = [];
foreach ($items as $item) {
    $label = trim(
        ($item['name_ar'] ?: '') . ' | ' .
        ($item['name_en'] ?: '') . ' | ' .
        ($item['code'] ?: ''),
        ' |'
    );

    $results[] = [
        'id' => (int)$item['id'],
        'text' => $label
    ];
}

echo json_encode([
    'results' => $results,
    'pagination' => ['more' => count($results) === $limit]
], JSON_UNESCAPED_UNICODE);