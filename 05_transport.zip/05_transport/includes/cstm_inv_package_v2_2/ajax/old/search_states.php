<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config.php';
require_once LIBS. '/query/config.php';

$q = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

$pdo = db_conn();
$sql = "SELECT id, name_ar, name_en, code
        FROM states
        WHERE :q = '' OR name_ar LIKE :like_q OR name_en LIKE :like_q OR code LIKE :like_q
        ORDER BY name_ar ASC, name_en ASC, code ASC
        LIMIT {$limit} OFFSET {$offset}";
$stmt = $pdo->prepare($sql);
$stmt->execute([
    'q' => $q,
    'like_q' => "%{$q}%",
]);
$items = $stmt->fetchAll() ?: [];

$results = [];
foreach ($items as $item) {
    $label = trim(($item['name_ar'] ?: '') . ' | ' . ($item['name_en'] ?: '') . ' | ' . ($item['code'] ?: ''), ' |');
    $results[] = [
        'id' => (int)$item['id'],
        'text' => $label,
    ];
}

echo json_encode([
    'results' => $results,
    'pagination' => ['more' => count($results) === $limit],
], JSON_UNESCAPED_UNICODE);
