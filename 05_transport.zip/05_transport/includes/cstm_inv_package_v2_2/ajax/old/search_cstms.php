<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config.php';
require_once LIBS. '/query/config.php';
$q = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

$pdo = db_conn();
$sql = "SELECT c.id, c.name_ar, c.name_en, c.phone1, c.email, s.name_ar AS state_name_ar, s.code AS state_code
        FROM cstms c
        LEFT JOIN states s ON s.id = c.state_id
        WHERE :q = '' OR c.name_ar LIKE :like_q OR c.name_en LIKE :like_q OR c.phone1 LIKE :like_q OR c.email LIKE :like_q
        ORDER BY c.name_ar ASC, c.name_en ASC
        LIMIT {$limit} OFFSET {$offset}";
$stmt = $pdo->prepare($sql);
$stmt->execute([
    'q' => $q,
    'like_q' => "%{$q}%",
]);
$items = $stmt->fetchAll() ?: [];

$results = [];
foreach ($items as $item) {
    $label = trim(($item['name_ar'] ?: '') . ' | ' . ($item['name_en'] ?: '') . ' | ' . ($item['phone1'] ?: '') . ' | ' . ($item['state_name_ar'] ?: $item['state_code'] ?: ''), ' |');
    $results[] = [
        'id' => (int)$item['id'],
        'text' => $label ?: ('عميل #' . $item['id']),
    ];
}

echo json_encode([
    'results' => $results,
    'pagination' => ['more' => count($results) === $limit],
], JSON_UNESCAPED_UNICODE);
