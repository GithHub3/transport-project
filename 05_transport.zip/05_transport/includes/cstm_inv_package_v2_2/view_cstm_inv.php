<?php
require_once __DIR__ . '/lib_invoice.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$invoice = get_invoice_full($id);
if (!$invoice) {
    http_response_code(404);
    echo 'الفاتورة غير موجودة';
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>عرض الفاتورة</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="container py-4 py-lg-5">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4 no-print">
        <div>
            <h1 class="h3 mb-1">عرض الفاتورة #<?php echo (int)$invoice['id']; ?></h1>
            <div class="text-secondary">هذه الصفحة تظهر الفاتورة بعد الحفظ مع كل العناصر والأصناف والأجزاء.</div>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="create_cstm_inv.php?id=<?php echo (int)$invoice['id']; ?>" class="btn btn-success rounded-pill px-4">تعديل</a>
            <button onclick="window.print()" class="btn btn-outline-primary rounded-pill px-4">طباعة</button>
            <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4">كل الفواتير</a>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 invoice-view-card">
        <div class="card-body p-4 p-lg-5">
            <div class="row g-4 mb-4">
                <div class="col-lg-6">
                    <h2 class="h5 mb-3">بيانات الفاتورة</h2>
                    <div class="row g-2 text-break">
                        <div class="col-6 text-secondary">رقم الفاتورة</div><div class="col-6"><?php echo h($invoice['inv_num'] ?: '-'); ?></div>
                        <div class="col-6 text-secondary">التاريخ</div><div class="col-6"><?php echo h($invoice['dt']); ?></div>
                        <div class="col-6 text-secondary">ship_id</div><div class="col-6"><?php echo h($invoice['ship_id'] ?: '-'); ?></div>
                        <div class="col-6 text-secondary">العملة</div><div class="col-6"><?php echo h(($invoice['coin_name'] ?: '-') . ' ' . ($invoice['coin_code'] ? '(' . $invoice['coin_code'] . ')' : '')); ?></div>
                        <div class="col-6 text-secondary">المبلغ</div><div class="col-6"><?php echo h(number_format((float)$invoice['amount'], 2)); ?></div>
                        <div class="col-6 text-secondary">المدفوع</div><div class="col-6"><?php echo h(number_format((float)$invoice['paid'], 2)); ?></div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <h2 class="h5 mb-3">الأطراف والمسار</h2>
                    <div class="row g-2 text-break">
                        <div class="col-4 text-secondary">المرسل</div><div class="col-8"><?php echo h(trim(($invoice['send_name_ar'] ?: '') . ' ' . ($invoice['send_name_en'] ?: '')) ?: '-'); ?></div>
                        <div class="col-4 text-secondary">المستلم</div><div class="col-8"><?php echo h(trim(($invoice['receive_name_ar'] ?: '') . ' ' . ($invoice['receive_name_en'] ?: '')) ?: '-'); ?></div>
                        <div class="col-4 text-secondary">من</div><div class="col-8"><?php echo h(trim(($invoice['state_from_ar'] ?: '') . ' | ' . ($invoice['state_from_en'] ?: '') . ' | ' . ($invoice['state_from_code'] ?: ''), ' |') ?: '-'); ?></div>
                        <div class="col-4 text-secondary">إلى</div><div class="col-8"><?php echo h(trim(($invoice['state_to_ar'] ?: '') . ' | ' . ($invoice['state_to_en'] ?: '') . ' | ' . ($invoice['state_to_code'] ?: ''), ' |') ?: '-'); ?></div>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <h2 class="h5 mb-3">ملاحظة الفاتورة</h2>
                <div class="border rounded-4 p-3 bg-light"><?php echo nl2br(h($invoice['note'] ?: 'لا توجد ملاحظة')); ?></div>
            </div>

            <div class="mb-3 d-flex justify-content-between align-items-center">
                <h2 class="h5 mb-0">العناصر</h2>
                <span class="badge text-bg-primary rounded-pill"><?php echo count($invoice['items']); ?> عنصر</span>
            </div>

            <?php if (!$invoice['items']): ?>
                <div class="alert alert-secondary">لا توجد عناصر.</div>
            <?php else: ?>
                <?php foreach ($invoice['items'] as $itemIndex => $item): ?>
                    <div class="card border rounded-4 mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                                <h3 class="h6 mb-0">عنصر <?php echo $itemIndex + 1; ?></h3>
                                <span class="text-secondary small">ID: <?php echo (int)$item['id']; ?></span>
                            </div>
                            <div class="row g-2 mb-3">
                                <div class="col-md-3"><span class="text-secondary">inv_num:</span> <?php echo h($item['inv_num'] ?: '-'); ?></div>
                                <div class="col-md-3"><span class="text-secondary">name_ar:</span> <?php echo h($item['name_ar'] ?: '-'); ?></div>
                                <div class="col-md-3"><span class="text-secondary">name_en:</span> <?php echo h($item['name_en'] ?: '-'); ?></div>
                                <div class="col-md-3"><span class="text-secondary">dt:</span> <?php echo h($item['dt']); ?></div>
                                <div class="col-md-3"><span class="text-secondary">amount:</span> <?php echo h(number_format((float)$item['amount'], 2)); ?></div>
                                <div class="col-md-3"><span class="text-secondary">paid:</span> <?php echo h(number_format((float)$item['paid'], 2)); ?></div>
                                <div class="col-md-6"><span class="text-secondary">note:</span> <?php echo h($item['note'] ?: '-'); ?></div>
                            </div>

                            <div class="ps-lg-3 border-start-subtle">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h4 class="h6 mb-0">Classes</h4>
                                    <span class="badge text-bg-secondary rounded-pill"><?php echo count($item['classes']); ?></span>
                                </div>
                                <?php foreach ($item['classes'] as $classIndex => $class): ?>
                                    <div class="border rounded-4 p-3 mb-3 bg-light-subtle">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <div class="fw-semibold">Class <?php echo $classIndex + 1; ?></div>
                                            <div class="small text-secondary">ID: <?php echo (int)$class['id']; ?></div>
                                        </div>
                                        <div class="row g-2 mb-3">
                                            <div class="col-md-3"><span class="text-secondary">name_ar:</span> <?php echo h($class['name_ar'] ?: '-'); ?></div>
                                            <div class="col-md-3"><span class="text-secondary">name_en:</span> <?php echo h($class['name_en'] ?: '-'); ?></div>
                                            <div class="col-md-2"><span class="text-secondary">unit:</span> <?php echo h($class['unit']); ?></div>
                                            <div class="col-md-4"><span class="text-secondary">note:</span> <?php echo h($class['note'] ?: '-'); ?></div>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-sm align-middle mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>qty</th>
                                                        <th>height</th>
                                                        <th>length</th>
                                                        <th>width</th>
                                                        <th>kg</th>
                                                        <th>note</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($class['parts'] as $partIndex => $part): ?>
                                                        <tr>
                                                            <td><?php echo $partIndex + 1; ?></td>
                                                            <td><?php echo h($part['qty']); ?></td>
                                                            <td><?php echo h($part['height'] ?? '-'); ?></td>
                                                            <td><?php echo h($part['length'] ?? '-'); ?></td>
                                                            <td><?php echo h($part['width'] ?? '-'); ?></td>
                                                            <td><?php echo h($part['kg'] ?? '-'); ?></td>
                                                            <td><?php echo h($part['note'] ?: '-'); ?></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                    <?php if (!$class['parts']): ?>
                                                        <tr><td colspan="7" class="text-center text-secondary">لا توجد أجزاء.</td></tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                                <?php if (!$item['classes']): ?>
                                    <div class="text-secondary">لا توجد أصناف لهذا العنصر.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
