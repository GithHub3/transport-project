<?php
class Database {
    private $host = 'localhost';
    private $db_name = 'transport_01';
    private $username = 'root';
    private $password = '123';
    private $conn;

    public function getConnection() {
        if ($this->conn instanceof PDO) {
            return $this->conn;
        }

        $dsn = "mysql:host={$this->host};dbname={$this->db_name};charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];

        $this->conn = new PDO($dsn, $this->username, $this->password, $options);
        return $this->conn;
    }
}

function db_conn() {
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $db = new Database();
    $pdo = $db->getConnection();
    return $pdo;
}
