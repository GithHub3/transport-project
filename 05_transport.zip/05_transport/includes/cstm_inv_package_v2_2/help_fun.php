<?php
require_once __DIR__.'/config.php';
// require_once __DIR__.'/../../../includes/config.php';


class CRUD {
    private $db;
    private $connection;
    
    public function __construct() {
        $this->db = new Database();
        $this->connection = $this->db->getConnection();
    }
    
    // دالة الإضافة (INSERT)
    public function insert($table, $data) {
        try {
            $columns = implode(", ", array_keys($data));
            $placeholders = ":" . implode(", :", array_keys($data));
            
            $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
            $stmt = $this->connection->prepare($sql);
            
            return $stmt->execute($data);
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
            return false;
        }
    }



// دالة الإضافة (INSERT) مع ارجاع id

public function insertId($table, $data) {
        try {
            $columns = implode(", ", array_keys($data));
            $placeholders = ":" . implode(", :", array_keys($data));
            
            $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
            $stmt = $this->connection->prepare($sql);
            
            // تنفيذ الإضافة
            if ($stmt->execute($data)) {
                // الحصول على الـ ID الأخير المُدخل
                $lastId = $this->connection->lastInsertId();
                return $lastId;
            } else {
                return false;
            }
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
            return false;
        }
    }
    
    // دالة التحديث (UPDATE)
    public function update($table, $data, $conditions) {
        try {
            $setClause = "";
            foreach(array_keys($data) as $key) {
                $setClause .= "$key = :$key, ";
            }
            $setClause = rtrim($setClause, ", ");
            
            $whereClause = "";
            $conditionParams = [];
            foreach($conditions as $key => $value) {
                $whereClause .= "$key = :cond_$key AND ";
                $conditionParams["cond_$key"] = $value;
            }
            $whereClause = rtrim($whereClause, " AND ");
            
            $sql = "UPDATE $table SET $setClause WHERE $whereClause";
            $stmt = $this->connection->prepare($sql);
            
            $allParams = array_merge($data, $conditionParams);
            return $stmt->execute($allParams);
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
            return false;
        }
    }
    
    // دالة الحذف (DELETE)
    public function delete($table, $conditions) {
        try {
            $whereClause = "";
            $params = [];
            foreach($conditions as $key => $value) {
                $whereClause .= "$key = :$key AND ";
                $params[$key] = $value;
            }
            $whereClause = rtrim($whereClause, " AND ");
            
            $sql = "DELETE FROM $table WHERE $whereClause";
            $stmt = $this->connection->prepare($sql);
            
            return $stmt->execute($params);
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
            return false;
        }
    }
    
    // دالة الاستدعاء (SELECT) مع إمكانية إضافة شروط
    public function select($table, $columns = "*", $conditions = [], $orderBy = "", $limit = "") {
        try {
            if(is_array($columns)) {
                $columns = implode(", ", $columns);
            }
            
            $sql = "SELECT $columns FROM $table";
            $params = [];
            
            if(!empty($conditions)) {
                $whereClause = "";
                foreach($conditions as $key => $value) {
                    $whereClause .= "$key = :$key AND ";
                    $params[$key] = $value;
                }
                $whereClause = rtrim($whereClause, " AND ");
                $sql .= " WHERE $whereClause";
            }
            
            if(!empty($orderBy)) {
                $sql .= " ORDER BY $orderBy";
            }
            
            if(!empty($limit)) {
                $sql .= " LIMIT $limit";
            }
            
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
            return false;
        }
    }
    
    // دالة الاستدعاء بسجل واحد فقط
    public function selectOne($table, $columns = "*", $conditions = []) {
        $result = $this->select($table, $columns, $conditions, "", "1");
        return ($result && count($result) > 0) ? $result[0] : false;
    }



// دالة استدعاء عادية
    public function sel($table, $columns = "*", $conditions = [], $orderBy = "", $limit = "") {
        try {
            if(is_array($columns)) {
                $columns = implode(", ", $columns);
            }
            
            $sql = "SELECT $columns FROM $table";
            $params = [];
            
            if(!empty($conditions)) {
                $whereClause = "";
                foreach($conditions as $key => $value) {
                    $whereClause .= "$key = :$key AND ";
                    $params[$key] = $value;
                }
                $whereClause = rtrim($whereClause, " AND ");
                $sql .= " WHERE $whereClause";
            }
            
            if(!empty($orderBy)) {
                $sql .= " ORDER BY $orderBy";
            }
            
            if(!empty($limit)) {
                $sql .= " LIMIT $limit";
            }
            
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
            return false;
        }
    }
    
    
    // دالة العد (COUNT)
    public function count($table, $conditions = []) {
        $result = $this->select($table, "COUNT(*) as total", $conditions);
        return ($result && count($result) > 0) ? $result[0]['total'] : 0;
    }
}



// _____________________________________________________
// _____________________________________________________
// _____________________________________________________


